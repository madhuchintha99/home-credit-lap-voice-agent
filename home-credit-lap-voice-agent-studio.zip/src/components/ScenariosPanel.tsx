import React, { useState } from 'react';
import { 
  Play, 
  CheckCircle2, 
  AlertTriangle, 
  ArrowRight, 
  ShieldAlert, 
  PhoneCall, 
  Layers, 
  Sliders,
  Sparkles,
  Info
} from 'lucide-react';
import { TestScenario, PromptVariables } from '../types/agent';
import { TEST_SCENARIOS } from '../data/scenarios';

interface ScenariosPanelProps {
  onSelectScenario: (scenario: TestScenario) => void;
  onUpdateCustomerName: (name: string) => void;
  variables: PromptVariables;
}

export const ScenariosPanel: React.FC<ScenariosPanelProps> = ({
  onSelectScenario,
  onUpdateCustomerName,
  variables,
}) => {
  const [selectedScenarioId, setSelectedScenarioId] = useState<string>(TEST_SCENARIOS[0].id);

  const activeScenario = TEST_SCENARIOS.find((s) => s.id === selectedScenarioId) || TEST_SCENARIOS[0];

  const handleApplyScenario = (scenario: TestScenario) => {
    setSelectedScenarioId(scenario.id);
    onUpdateCustomerName(scenario.customerProfile.name);
    onSelectScenario(scenario);
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl flex flex-col h-full">
      {/* Top Banner */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <Sliders className="w-5 h-5 text-blue-400" />
            <h2 className="text-lg font-bold text-white">Automated Scenario Test Suite</h2>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Test and demonstrate all assignment business logic boundaries and immediate disqualification rules
          </p>
        </div>

        <div className="text-xs text-slate-400">
          <span className="font-semibold text-emerald-400">{TEST_SCENARIOS.length}</span> Verified Test Suites
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 mt-4 flex-1 overflow-hidden">
        {/* Scenario List (5 cols) */}
        <div className="lg:col-span-5 overflow-y-auto space-y-2.5 pr-2">
          {TEST_SCENARIOS.map((sc) => {
            const isSelected = sc.id === selectedScenarioId;
            return (
              <div
                key={sc.id}
                onClick={() => handleApplyScenario(sc)}
                className={`p-4 rounded-2xl border cursor-pointer transition-all ${
                  isSelected
                    ? 'bg-blue-950/40 border-blue-500/50 shadow-lg shadow-blue-950/50'
                    : 'bg-slate-950/60 border-slate-800/80 hover:bg-slate-800/50 hover:border-slate-700'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <h4 className="text-xs font-bold text-slate-100">{sc.title}</h4>
                  <span className={`px-2 py-0.5 text-[10px] font-bold rounded-full border ${sc.badgeColor}`}>
                    {sc.badge}
                  </span>
                </div>
                <p className="text-[11px] text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                  {sc.description}
                </p>
                <div className="mt-2.5 pt-2 border-t border-slate-800/50 flex items-center justify-between text-[10px] text-slate-500">
                  <span>Customer: <strong className="text-slate-300">{sc.customerProfile.name}</strong></span>
                  <span className="text-blue-400 font-medium flex items-center gap-1">
                    Load & Test <ArrowRight className="w-3 h-3" />
                  </span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Selected Scenario Deep-Dive & Script Walkthrough (7 cols) */}
        <div className="lg:col-span-7 bg-slate-950 border border-slate-800 rounded-2xl p-5 flex flex-col justify-between overflow-y-auto">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div>
                <span className={`px-2.5 py-0.5 text-xs font-bold rounded-full border ${activeScenario.badgeColor}`}>
                  {activeScenario.badge}
                </span>
                <h3 className="text-base font-bold text-white mt-1.5">{activeScenario.title}</h3>
              </div>
              <button
                onClick={() => handleApplyScenario(activeScenario)}
                className="bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold px-4 py-2.5 rounded-xl shadow-lg shadow-emerald-900/30 flex items-center gap-2 transition-all"
              >
                <PhoneCall className="w-4 h-4" />
                <span>Load in Simulator</span>
              </button>
            </div>

            {/* Profile Info */}
            <div className="my-3 p-3 bg-slate-900/80 rounded-xl border border-slate-800/80 text-xs grid grid-cols-2 gap-3">
              <div>
                <span className="text-slate-500 text-[10px] uppercase font-semibold">Test Customer</span>
                <p className="text-slate-200 font-semibold">{activeScenario.customerProfile.name}</p>
              </div>
              <div>
                <span className="text-slate-500 text-[10px] uppercase font-semibold">Expected Business Outcome</span>
                <p className="text-emerald-400 font-semibold">{activeScenario.customerProfile.expectedOutcome}</p>
              </div>
            </div>

            <p className="text-xs text-slate-400 leading-relaxed mb-4">
              {activeScenario.description}
            </p>

            {/* Turn-by-Turn Script Walkthrough */}
            <div>
              <h4 className="text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2.5 flex items-center gap-1.5">
                <Info className="w-3.5 h-3.5 text-blue-400" />
                Dialogue Script & Turn Validation
              </h4>
              <div className="space-y-2.5 max-h-[340px] overflow-y-auto pr-1">
                {activeScenario.script.map((turn, i) => (
                  <div key={i} className="p-3 bg-slate-900 rounded-xl border border-slate-800/80 text-xs">
                    <div className="flex items-center gap-2 text-[11px] font-semibold text-blue-300 mb-1">
                      <span className="w-4 h-4 rounded-full bg-blue-500/20 text-blue-400 flex items-center justify-center text-[10px]">
                        {i + 1}
                      </span>
                      <span>Customer Turn:</span>
                    </div>
                    <p className="text-slate-200 italic pl-6 bg-slate-950/60 p-2 rounded-lg border border-slate-800/60">
                      "{turn.customerTurn}"
                    </p>
                    <div className="mt-2 text-[11px] text-emerald-400/90 pl-6 flex items-start gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                      <span>{turn.expectedResponseSummary}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
