import React from 'react';
import { EligibilityData, CallStage } from '../types/agent';
import { 
  Building2, 
  Users, 
  FileText, 
  Banknote, 
  Briefcase, 
  TrendingUp, 
  Calendar, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  AlertTriangle,
  ArrowRightCircle
} from 'lucide-react';

interface ChecklistHUDProps {
  data: EligibilityData;
  currentStage: CallStage;
  disqualificationReason?: string;
}

export const ChecklistHUD: React.FC<ChecklistHUDProps> = ({
  data,
  currentStage,
  disqualificationReason,
}) => {
  // Count how many criteria are evaluated
  const items = [
    {
      id: 1,
      name: 'Property Type',
      icon: Building2,
      value: data.propertyType ? `${data.propertyType}` : null,
      status: data.propertyTypeEligible === true ? 'passed' : data.propertyTypeEligible === false ? 'failed' : 'pending',
      rule: 'Eligible: Residential, Commercial, Industrial. Ineligible: Agricultural.',
      details: data.propertyType === 'Agricultural' ? 'Disqualified (Agricultural Land)' : data.propertyType ? 'Eligible Property' : 'Pending response',
    },
    {
      id: 2,
      name: 'Ownership Status',
      icon: Users,
      value: data.ownershipStatus ? `${data.ownershipStatus} Owner` : null,
      status: data.ownershipEligible === true ? 'passed' : data.ownershipEligible === false ? 'failed' : 'pending',
      rule: 'Eligible: Both Sole & Joint ownership are acceptable.',
      details: data.ownershipStatus ? `${data.ownershipStatus} Ownership Verified` : 'Pending response',
    },
    {
      id: 3,
      name: 'Document Availability',
      icon: FileText,
      value: data.documentStatus ? `${data.documentStatus} Papers` : null,
      status: data.documentEligible === true ? 'passed' : data.documentEligible === false ? 'failed' : 'pending',
      rule: 'Eligible: Must have Original registered documents ready.',
      details: data.documentEligible === false ? 'Disqualified (Missing Originals)' : data.hasOriginalDocs ? 'Original Documents In Hand' : 'Pending response',
    },
    {
      id: 4,
      name: 'Loan Amount',
      icon: Banknote,
      value: data.loanAmountApproved 
        ? `₹${(data.loanAmountApproved / 100000).toFixed(1)} Lakhs` 
        : data.loanAmountRequested 
        ? `₹${(data.loanAmountRequested / 100000).toFixed(1)} Lakhs (Requested)` 
        : null,
      status: data.loanAmountEligible === true 
        ? 'passed' 
        : (data.loanAmountRequested && data.loanAmountRequested > 7500000 && !data.loanAmountNegotiated)
        ? 'warning'
        : 'pending',
      rule: 'Eligible: Up to ₹75,00,000 (75 Lakhs). Cap renegotiation if higher.',
      details: data.loanAmountNegotiated 
        ? 'Negotiated to ₹75 Lakhs Max Limit' 
        : (data.loanAmountRequested && data.loanAmountRequested > 7500000)
        ? 'Exceeds ₹75L Ceiling (Renegotiating)'
        : data.loanAmountApproved
        ? 'Within Approved ₹75L Limit'
        : 'Pending response',
    },
    {
      id: 5,
      name: 'Occupation & Income Mode',
      icon: Briefcase,
      value: (data.occupation || data.incomeMode) 
        ? `${data.occupation || 'N/A'} • ${data.incomeMode ? `${data.incomeMode} Credit` : 'Income Pending'}` 
        : null,
      status: data.incomeEligible === true ? 'passed' : data.incomeEligible === false ? 'failed' : 'pending',
      rule: 'Eligible: Salaried or Self-Employed with official Bank transfer. Cash is ineligible.',
      details: data.incomeEligible === false ? 'Disqualified (Cash Income)' : data.incomeEligible ? 'Bank-Credited Income Verified' : 'Pending response',
    },
    {
      id: 6,
      name: 'Market Value',
      icon: TrendingUp,
      value: data.marketValue ? `₹${(data.marketValue / 100000).toFixed(1)} Lakhs` : null,
      status: data.marketValue ? 'passed' : 'pending',
      rule: 'Estimated fair current market valuation of the mortgaged property.',
      details: data.marketValue ? `Estimated Valuation ₹${(data.marketValue / 100000).toFixed(1)}L` : 'Pending response',
    },
    {
      id: 7,
      name: 'Tenure (Repayment)',
      icon: Calendar,
      value: data.tenureYears ? `${data.tenureYears} Years` : null,
      status: data.tenureEligible === true ? 'passed' : data.tenureEligible === false ? 'failed' : 'pending',
      rule: 'Eligible: Strictly between 3 and 15 years.',
      details: data.tenureEligible === false ? 'Disqualified (Out of 3-15 yrs range)' : data.tenureEligible ? 'Within 3-15 Year Window' : 'Pending response',
    },
  ];

  const passedCount = items.filter((i) => i.status === 'passed').length;
  const isFailed = items.some((i) => i.status === 'failed') || currentStage === 'DISQUALIFIED';

  const getStageBadge = (stage: CallStage) => {
    switch (stage) {
      case 'QUALIFIED_HANDOFF':
        return { text: '7/7 QUALIFIED • SENIOR HANDOFF', color: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40' };
      case 'DISQUALIFIED':
        return { text: 'IMMEDIATELY DISQUALIFIED', color: 'bg-rose-500/20 text-rose-400 border-rose-500/40' };
      case 'BALANCE_TRANSFER_SWITCH':
        return { text: 'BALANCE TRANSFER SPECIALIST SWITCH', color: 'bg-amber-500/20 text-amber-400 border-amber-500/40' };
      case 'CALLBACK_SCHEDULED':
        return { text: 'BUSY • CALLBACK SCHEDULED', color: 'bg-sky-500/20 text-sky-400 border-sky-500/40' };
      case 'PRESENTING_OFFER':
        return { text: 'OFFER PRESENTATION (UP TO 75L)', color: 'bg-indigo-500/20 text-indigo-400 border-indigo-500/40' };
      case 'GREETING_VERIFICATION':
        return { text: 'GREETING & IDENTITY VERIFICATION', color: 'bg-slate-500/20 text-slate-300 border-slate-500/40' };
      case 'CALL_ENDED':
        return { text: 'CALL COMPLETED', color: 'bg-neutral-600/20 text-neutral-400 border-neutral-600/40' };
      default:
        return { text: 'GATHERING ELIGIBILITY CHECKLIST', color: 'bg-blue-500/20 text-blue-400 border-blue-500/40' };
    }
  };

  const stageBadge = getStageBadge(currentStage);

  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl flex flex-col h-full backdrop-blur-sm">
      {/* Top Banner */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <span className="flex h-2.5 w-2.5 rounded-full bg-emerald-400 animate-pulse" />
            <h3 className="text-sm font-semibold uppercase tracking-wider text-slate-400">
              Live Qualification Checklist
            </h3>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Real-time 7-point eligibility gate tracker with immediate disqualification guards
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className={`px-2.5 py-1 text-xs font-semibold rounded-full border ${stageBadge.color}`}>
            {stageBadge.text}
          </span>
          <div className="bg-slate-800/80 px-3 py-1 rounded-full text-xs font-medium text-slate-300 border border-slate-700">
            <span className="text-emerald-400 font-bold">{passedCount}</span> / 7 Verified
          </div>
        </div>
      </div>

      {/* Disqualification Banner */}
      {isFailed && disqualificationReason && (
        <div className="my-3 p-3 bg-rose-950/40 border border-rose-800/60 rounded-xl flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
          <div className="text-xs">
            <p className="font-semibold text-rose-300">Underwriting Disqualification Gate Triggered</p>
            <p className="text-rose-400/90 mt-0.5">{disqualificationReason}</p>
            <p className="text-slate-400 mt-1 italic">
              Bot immediately concluded call with polite policy explanation without asking remaining questions.
            </p>
          </div>
        </div>
      )}

      {/* Balance Transfer Switch Banner */}
      {currentStage === 'BALANCE_TRANSFER_SWITCH' && (
        <div className="my-3 p-3 bg-amber-950/40 border border-amber-800/60 rounded-xl flex items-start gap-3">
          <ArrowRightCircle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
          <div className="text-xs">
            <p className="font-semibold text-amber-300">The "Transfer" Logic Switch Triggered</p>
            <p className="text-amber-400/90 mt-0.5">
              Customer identified existing loan / EMI reduction. Redirected to Balance Transfer Specialist desk.
            </p>
          </div>
        </div>
      )}

      {/* Progress Track */}
      <div className="w-full bg-slate-800/60 h-2 rounded-full my-3 overflow-hidden">
        <div
          className={`h-full transition-all duration-500 rounded-full ${
            isFailed
              ? 'bg-rose-500'
              : currentStage === 'BALANCE_TRANSFER_SWITCH'
              ? 'bg-amber-500'
              : passedCount === 7
              ? 'bg-emerald-500'
              : 'bg-blue-500'
          }`}
          style={{ width: `${(passedCount / 7) * 100}%` }}
        />
      </div>

      {/* 7 Checklist Cards */}
      <div className="flex-1 overflow-y-auto space-y-2.5 pr-1">
        {items.map((item) => {
          const Icon = item.icon;
          return (
            <div
              key={item.id}
              className={`p-3 rounded-xl border transition-all text-xs ${
                item.status === 'passed'
                  ? 'bg-emerald-950/20 border-emerald-800/40 text-slate-200'
                  : item.status === 'failed'
                  ? 'bg-rose-950/30 border-rose-800/50 text-slate-200'
                  : item.status === 'warning'
                  ? 'bg-amber-950/20 border-amber-800/40 text-slate-200'
                  : 'bg-slate-800/40 border-slate-800 text-slate-400'
              }`}
            >
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2 font-medium">
                  <div
                    className={`p-1.5 rounded-lg ${
                      item.status === 'passed'
                        ? 'bg-emerald-500/20 text-emerald-400'
                        : item.status === 'failed'
                        ? 'bg-rose-500/20 text-rose-400'
                        : item.status === 'warning'
                        ? 'bg-amber-500/20 text-amber-400'
                        : 'bg-slate-700/50 text-slate-400'
                    }`}
                  >
                    <Icon className="w-3.5 h-3.5" />
                  </div>
                  <span className="text-slate-200 font-semibold">{item.id}. {item.name}</span>
                </div>

                <div className="flex items-center gap-1.5">
                  {item.status === 'passed' && (
                    <span className="flex items-center gap-1 text-[11px] font-semibold text-emerald-400">
                      <CheckCircle2 className="w-3.5 h-3.5" /> Passed
                    </span>
                  )}
                  {item.status === 'failed' && (
                    <span className="flex items-center gap-1 text-[11px] font-semibold text-rose-400">
                      <XCircle className="w-3.5 h-3.5" /> Ineligible
                    </span>
                  )}
                  {item.status === 'warning' && (
                    <span className="flex items-center gap-1 text-[11px] font-semibold text-amber-400">
                      <AlertTriangle className="w-3.5 h-3.5" /> Renegotiating
                    </span>
                  )}
                  {item.status === 'pending' && (
                    <span className="flex items-center gap-1 text-[11px] text-slate-500">
                      <Clock className="w-3.5 h-3.5" /> Pending
                    </span>
                  )}
                </div>
              </div>

              {/* Extracted Value Badge */}
              <div className="mt-2 flex items-center justify-between gap-2 pt-1.5 border-t border-slate-700/30">
                <span className="text-[11px] text-slate-400 font-mono">
                  {item.value ? (
                    <span className="text-blue-300 font-semibold">{item.value}</span>
                  ) : (
                    <span className="text-slate-500 italic">Not extracted yet</span>
                  )}
                </span>
                <span className="text-[10px] text-slate-400 truncate max-w-[200px]" title={item.rule}>
                  {item.details}
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Bottom Summary Callout */}
      <div className="mt-4 pt-3 border-t border-slate-800 text-[11px] text-slate-400 flex items-center justify-between">
        <span>Handoff Gate: <strong className="text-slate-300">All 7 mandatory</strong></span>
        <span className="text-emerald-400 font-medium">Max Limit: ₹75 Lakhs</span>
      </div>
    </div>
  );
};
