import React from 'react';
import { 
  PhoneCall, 
  FileCode2, 
  Sliders, 
  History, 
  FileCheck2, 
  ShieldCheck, 
  Sparkles,
  Building2,
  Headphones
} from 'lucide-react';
import { PromptVariables } from '../types/agent';

export type ActiveTab = 'simulator' | 'prompt' | 'scenarios' | 'logs' | 'submission';

interface HeaderProps {
  activeTab: ActiveTab;
  onChangeTab: (tab: ActiveTab) => void;
  variables: PromptVariables;
  logsCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  onChangeTab,
  variables,
  logsCount,
}) => {
  const tabs = [
    { id: 'simulator', label: 'Live Voice Simulator', icon: PhoneCall, badge: 'Live Audio' },
    { id: 'prompt', label: 'System Prompt & Export', icon: FileCode2, badge: 'Retell / Bolna' },
    { id: 'scenarios', label: 'Scenario Test Suites', icon: Sliders, badge: '7 Scenarios' },
    { id: 'logs', label: 'Call Logs & Transcripts', icon: History, count: logsCount },
    { id: 'submission', label: 'Submission Package', icon: FileCheck2, badge: 'Assignment' },
  ];

  return (
    <header className="border-b border-slate-800 bg-slate-950/80 backdrop-blur-md sticky top-0 z-30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row items-center justify-between py-3.5 gap-4">
          {/* Logo & Brand Title */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-rose-600 to-red-500 flex items-center justify-center text-white shadow-lg shadow-rose-900/40">
              <Building2 className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base font-bold text-white tracking-tight">
                  Home Credit LAP Voice Agent Studio
                </h1>
                <span className="bg-emerald-950/80 text-emerald-400 text-[10px] font-bold px-2 py-0.5 rounded-full border border-emerald-800/50">
                  Pre-approved LAP (₹75L)
                </span>
              </div>
              <p className="text-xs text-slate-400">
                AI Voice Agent qualification engine, real-time checklist HUD & prompt design
              </p>
            </div>
          </div>

          {/* Nav Tabs */}
          <nav className="flex items-center gap-1.5 bg-slate-900/90 p-1.5 rounded-2xl border border-slate-800 text-xs font-medium">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => onChangeTab(tab.id as ActiveTab)}
                  className={`flex items-center gap-2 px-3 py-2 rounded-xl transition-all ${
                    isActive
                      ? 'bg-blue-600 text-white shadow-md shadow-blue-900/40'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{tab.label}</span>
                  {tab.badge && (
                    <span
                      className={`text-[9px] px-1.5 py-0.2 rounded-full font-semibold ${
                        isActive ? 'bg-blue-700 text-blue-100' : 'bg-slate-800 text-slate-400'
                      }`}
                    >
                      {tab.badge}
                    </span>
                  )}
                  {tab.count !== undefined && tab.count > 0 && (
                    <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-1.5 py-0.2 rounded-full font-bold">
                      {tab.count}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>
      </div>
    </header>
  );
};
