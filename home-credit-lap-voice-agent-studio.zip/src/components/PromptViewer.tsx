import React, { useState } from 'react';
import { 
  Copy, 
  Check, 
  Download, 
  Settings2, 
  FileCode2, 
  Layers, 
  ExternalLink,
  BookOpen,
  Terminal,
  Cpu
} from 'lucide-react';
import { PromptVariables } from '../types/agent';
import { generateSystemPrompt, PRODUCTION_RETELL_AI_CONFIG } from '../data/promptTemplate';

interface PromptViewerProps {
  variables: PromptVariables;
  onUpdateVariables: (newVars: PromptVariables) => void;
}

export const PromptViewer: React.FC<PromptViewerProps> = ({
  variables,
  onUpdateVariables,
}) => {
  const [copied, setCopied] = useState(false);
  const [copiedJson, setCopiedJson] = useState(false);
  const [activeTab, setActiveTab] = useState<'prompt' | 'variables' | 'retell_json' | 'guide'>('prompt');

  const fullPromptText = generateSystemPrompt(variables);

  const handleCopy = () => {
    navigator.clipboard.writeText(fullPromptText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const element = document.createElement('a');
    const file = new Blob([fullPromptText], { type: 'text/markdown' });
    element.href = URL.createObjectURL(file);
    element.download = 'home_credit_lap_system_prompt.md';
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  const handleCopyJson = () => {
    navigator.clipboard.writeText(JSON.stringify(PRODUCTION_RETELL_AI_CONFIG, null, 2));
    setCopiedJson(true);
    setTimeout(() => setCopiedJson(false), 2000);
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl flex flex-col h-full">
      {/* Top Bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <FileCode2 className="w-5 h-5 text-blue-400" />
            <h2 className="text-lg font-bold text-white">System Prompt Engineering & Retell / Bolna Export</h2>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Production-grade prompt with strict 7-point qualification gates, immediate disqualification boundaries, and out-of-order slot filling.
          </p>
        </div>

        {/* Tab Switcher */}
        <div className="flex items-center gap-1.5 bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs">
          <button
            onClick={() => setActiveTab('prompt')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-all ${
              activeTab === 'prompt' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            System Prompt Text
          </button>
          <button
            onClick={() => setActiveTab('variables')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-all ${
              activeTab === 'variables' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Edit Prompt Variables
          </button>
          <button
            onClick={() => setActiveTab('retell_json')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-all ${
              activeTab === 'retell_json' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Retell / Bolna JSON
          </button>
          <button
            onClick={() => setActiveTab('guide')}
            className={`px-3 py-1.5 rounded-lg font-medium transition-all ${
              activeTab === 'guide' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Deployment Guide
          </button>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2">
          <button
            onClick={handleCopy}
            className="flex items-center gap-1.5 bg-blue-600 hover:bg-blue-500 text-white px-3.5 py-2 rounded-xl text-xs font-semibold shadow-lg shadow-blue-900/30 transition-all"
          >
            {copied ? <Check className="w-4 h-4 text-emerald-300" /> : <Copy className="w-4 h-4" />}
            <span>{copied ? 'Copied Prompt!' : 'Copy System Prompt'}</span>
          </button>
          <button
            onClick={handleDownload}
            className="flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 px-3 py-2 rounded-xl text-xs font-medium border border-slate-700 transition-all"
            title="Download as Markdown"
          >
            <Download className="w-4 h-4" />
            <span>Download .md</span>
          </button>
        </div>
      </div>

      {/* Main Tab Content */}
      <div className="flex-1 overflow-y-auto mt-4 pr-1">
        {activeTab === 'prompt' && (
          <div className="relative">
            <pre className="bg-slate-950 border border-slate-800/80 rounded-2xl p-6 text-xs text-slate-300 font-mono leading-relaxed whitespace-pre-wrap overflow-x-auto selection:bg-blue-600 selection:text-white">
              {fullPromptText}
            </pre>
          </div>
        )}

        {activeTab === 'variables' && (
          <div className="space-y-5 bg-slate-950 p-6 rounded-2xl border border-slate-800">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="text-sm font-semibold text-slate-200">
                Technical Specifications: User Prompt Variables (Section 4 of Assignment)
              </h3>
              <span className="text-xs text-slate-500">Live variables dynamically update prompt & simulator</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              <div>
                <label className="block text-slate-400 font-medium mb-1">Company Name (company_name)</label>
                <input
                  type="text"
                  value={variables.company_name}
                  onChange={(e) => onUpdateVariables({ ...variables, company_name: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2.5 text-slate-200 focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1">Customer Name (customer_name)</label>
                <input
                  type="text"
                  value={variables.customer_name}
                  onChange={(e) => onUpdateVariables({ ...variables, customer_name: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2.5 text-slate-200 focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1">Agent Name (agent_name)</label>
                <input
                  type="text"
                  value={variables.agent_name}
                  onChange={(e) => onUpdateVariables({ ...variables, agent_name: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2.5 text-slate-200 focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1">Agent Gender (Strict Persona Adherence)</label>
                <select
                  value={variables.agent_gender}
                  onChange={(e) => onUpdateVariables({ ...variables, agent_gender: e.target.value as 'Female' | 'Male' })}
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2.5 text-slate-200 focus:outline-none focus:border-blue-500"
                >
                  <option value="Female">Female (e.g. Priya)</option>
                  <option value="Male">Male (e.g. Aarav)</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1">Language to Speak (language_to_speak)</label>
                <select
                  value={variables.language_to_speak}
                  onChange={(e) => onUpdateVariables({ ...variables, language_to_speak: e.target.value as any })}
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3.5 py-2.5 text-slate-200 focus:outline-none focus:border-blue-500"
                >
                  <option value="English">English</option>
                  <option value="Hindi">Hindi</option>
                  <option value="Hinglish">Hinglish (Colloquial conversational)</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1">Current Date Context (current_date / day)</label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={variables.current_date}
                    readOnly
                    className="w-1/2 bg-slate-900/60 border border-slate-800 rounded-xl px-3 py-2 text-slate-400"
                  />
                  <input
                    type="text"
                    value={variables.current_day}
                    readOnly
                    className="w-1/2 bg-slate-900/60 border border-slate-800 rounded-xl px-3 py-2 text-slate-400"
                  />
                </div>
              </div>
            </div>

            <div>
              <label className="block text-slate-400 font-medium mb-1 text-xs">
                Additional Context from RAG (additional_context_from_rag)
              </label>
              <textarea
                rows={5}
                value={variables.additional_context_from_rag}
                onChange={(e) => onUpdateVariables({ ...variables, additional_context_from_rag: e.target.value })}
                className="w-full bg-slate-900 border border-slate-800 rounded-xl p-3 text-xs text-slate-300 font-mono leading-relaxed focus:outline-none focus:border-blue-500"
              />
            </div>
          </div>
        )}

        {activeTab === 'retell_json' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs text-slate-400">
                JSON Configuration payload compatible with Retell AI and Bolna agent provisioning API:
              </span>
              <button
                onClick={handleCopyJson}
                className="text-xs text-blue-400 hover:text-blue-300 flex items-center gap-1"
              >
                {copiedJson ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                {copiedJson ? 'Copied JSON!' : 'Copy JSON'}
              </button>
            </div>
            <pre className="bg-slate-950 border border-slate-800 rounded-2xl p-5 text-xs text-emerald-400 font-mono overflow-x-auto">
              {JSON.stringify(PRODUCTION_RETELL_AI_CONFIG, null, 2)}
            </pre>
          </div>
        )}

        {activeTab === 'guide' && (
          <div className="space-y-4 text-xs text-slate-300 bg-slate-950 p-6 rounded-2xl border border-slate-800 leading-relaxed">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <BookOpen className="w-4 h-4 text-blue-400" />
              Retell AI & Bolna Voice Agent Deployment Instructions
            </h3>

            <div className="space-y-3 pt-2">
              <div className="p-3 bg-slate-900 rounded-xl border border-slate-800">
                <p className="font-semibold text-blue-300">Step 1: Create an Agent in Retell AI / Bolna</p>
                <p className="text-slate-400 mt-1">
                  1. Log into your free trial on <strong className="text-slate-200">retellai.com</strong> or <strong className="text-slate-200">bolna.dev</strong>.<br />
                  2. Click <em>"Create Agent"</em> / <em>"New Voicebot"</em>.<br />
                  3. Select a professional Indian English voice (e.g. ElevenLabs Priya / Adrian or Deepgram Nova-2).
                </p>
              </div>

              <div className="p-3 bg-slate-900 rounded-xl border border-slate-800">
                <p className="font-semibold text-blue-300">Step 2: Paste the System Prompt</p>
                <p className="text-slate-400 mt-1">
                  1. Copy the full System Prompt from the <em>"System Prompt Text"</em> tab.<br />
                  2. Paste into the Agent's <strong>Instructions / General Prompt</strong> field.<br />
                  3. Set Begin Message to: <code>"Hello, good day! Am I speaking with Mr. Rajesh Sharma? This is Priya calling from Home Credit."</code>
                </p>
              </div>

              <div className="p-3 bg-slate-900 rounded-xl border border-slate-800">
                <p className="font-semibold text-blue-300">Step 3: Conduct Test Calls & Generate Call Recording Link</p>
                <p className="text-slate-400 mt-1">
                  1. Use Retell AI's Web Call simulator or dial the provided US/IN test phone number.<br />
                  2. Run the test scenarios (Full Qualified Lead, Agricultural Disqualification, Cash Income Disqualification, Balance Transfer switch).<br />
                  3. Copy the <strong>Public Call Recording & Transcript link</strong> from Retell/Bolna dashboard to submit alongside this prompt!
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
