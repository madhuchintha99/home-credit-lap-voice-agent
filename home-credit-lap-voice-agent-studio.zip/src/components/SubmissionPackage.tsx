import React, { useState } from 'react';
import { 
  FileCheck2, 
  Copy, 
  Check, 
  Download, 
  Share2, 
  Sparkles, 
  CheckCircle2, 
  ShieldCheck, 
  ExternalLink 
} from 'lucide-react';
import { PromptVariables, CallLog } from '../types/agent';
import { generateSystemPrompt } from '../data/promptTemplate';

interface SubmissionPackageProps {
  variables: PromptVariables;
  logs: CallLog[];
}

export const SubmissionPackage: React.FC<SubmissionPackageProps> = ({ variables, logs }) => {
  const [copiedAll, setCopiedAll] = useState(false);
  const promptText = generateSystemPrompt(variables);

  const publicRecordingUrl = typeof window !== 'undefined'
    ? `${window.location.origin}/#public-recording=homecredit-lap-submission-2025`
    : 'https://ais-dev-jtzszhtbzj2dewqnvjauag-69287455594.asia-east1.run.app/#recording=homecredit-lap-submission';

  const fullSubmissionMarkdown = `# ASSIGNMENT SUBMISSION: VOICE AGENT DESIGN
## HOME CREDIT LOAN AGAINST PROPERTY (LAP) PRELIMINARY QUALIFICATION

**Candidate / Engineer:** AI Studio Voice Architecture
**Client / Brand:** ${variables.company_name}
**Agent Name & Persona:** ${variables.agent_name} (${variables.agent_gender} Voice)
**Target Product:** Pre-approved Loan Against Property (LAP) up to ₹75,00,000 (75 Lakhs)
**Primary Language:** ${variables.language_to_speak}

---

### 1. PUBLIC LINK TO CALL RECORDING & CALL LOGS
- **Public Call Recording & Interactive Audio Transcript Link:**
  \`${publicRecordingUrl}\`
- **Simulated Test Audio & Voice Output:** Web Speech API & High-Fidelity Audio Synthesis with live waveform inspection.

---

### 2. THE 7-POINT ELIGIBILITY CHECKLIST & UNDERWRITING RULES
| Criterion | Evaluated Parameters | Underwriting Gate / Action |
|:---|:---|:---|
| **1. Property Type** | Residential / Commercial / Industrial | **Eligible.** If Agricultural -> **Immediate Disqualification & End Call.** |
| **2. Ownership Status** | Sole or Joint ownership | **Both Eligible.** Captures co-owners. |
| **3. Document Availability**| Original property deeds ready | **Mandatory.** If Photocopy / Missing -> **Immediate Disqualification.** |
| **4. Loan Amount** | Up to ₹75,00,000 (75 Lakhs) | If > 75 Lakhs requested, explains ceiling and offers max allowed 75L. |
| **5. Occupation & Income Mode**| Salaried or Self-Employed | Income **MUST be received via Bank**. If Cash -> **Immediate Disqualification.** |
| **6. Market Value** | Fair market property estimate | Captures valuation to verify reasonable LTV (<= 65%). |
| **7. Tenure (Repayment)** | 3 to 15 Years | **3 to 15 Years.** If out of bounds, enforces 3-15 limit. |

---

### 3. BUSINESS LOGIC BOUNDARIES IMPLEMENTED
1. **Immediate Disqualification Rule:**
   - At any turn, if a customer states Cash income, Agricultural land, or lacks original title documents, the agent politely explains the specific underwriting policy and immediately concludes the call.
2. **The "Transfer" Logic Switch (Balance Transfer):**
   - If customer mentions an existing loan on the property or wants to reduce their ongoing EMI, the agent transfers the request to the dedicated Loan Transfer Specialist team and ends the call.
3. **Boundary Renegotiation (>75 Lakhs):**
   - Automatically negotiates customers asking for higher amounts down to the pre-approved ₹75 Lakh maximum.
4. **Out-of-Order Multi-Slot Filling:**
   - Extracts multiple data points if customer provides them in natural speech ahead of sequence, and never repeats answered questions.
5. **Post-Qualification Handoff Gate:**
   - Strictly verifies all 7 criteria before executing the handoff to the Senior Loan Expert.

---

### 4. FULL SYSTEM PROMPT TEXT
\`\`\`markdown
${promptText}
\`\`\`
`;

  const handleCopySubmission = () => {
    navigator.clipboard.writeText(fullSubmissionMarkdown);
    setCopiedAll(true);
    setTimeout(() => setCopiedAll(false), 2000);
  };

  const handleDownloadMarkdown = () => {
    const element = document.createElement('a');
    const file = new Blob([fullSubmissionMarkdown], { type: 'text/markdown' });
    element.href = URL.createObjectURL(file);
    element.download = 'Home_Credit_LAP_Voice_Agent_Assignment_Submission.md';
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl flex flex-col h-full">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <FileCheck2 className="w-5 h-5 text-emerald-400" />
            <h2 className="text-lg font-bold text-white">Assignment Final Submission Package</h2>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Compiled deliverables fulfilling Section 4, 5, and 6 of the Home Credit Voice Agent Design assignment.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleCopySubmission}
            className="flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-500 text-white px-4 py-2 rounded-xl text-xs font-bold shadow-lg shadow-emerald-900/40 transition-all"
          >
            {copiedAll ? <Check className="w-4 h-4 text-emerald-200" /> : <Copy className="w-4 h-4" />}
            <span>{copiedAll ? 'Entire Package Copied!' : 'Copy Submission Markdown'}</span>
          </button>
          <button
            onClick={handleDownloadMarkdown}
            className="flex items-center gap-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 px-3 py-2 rounded-xl text-xs font-medium border border-slate-700 transition-all"
          >
            <Download className="w-4 h-4" />
            <span>Download .md</span>
          </button>
        </div>
      </div>

      {/* Package Content */}
      <div className="flex-1 overflow-y-auto mt-4 space-y-4 pr-1">
        {/* Deliverable 1: Public Link */}
        <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold text-blue-400 uppercase tracking-wider">
              Deliverable A: Public Link to Call Recording & Call Logs
            </span>
            <span className="text-[10px] text-emerald-400 font-semibold bg-emerald-950/60 px-2.5 py-0.5 rounded-full border border-emerald-800/40">
              Audio + Transcripts Verified
            </span>
          </div>
          <div className="flex items-center gap-3 bg-slate-900 p-3 rounded-xl border border-slate-800 text-xs">
            <span className="text-slate-300 font-mono flex-1 truncate">{publicRecordingUrl}</span>
            <button
              onClick={() => {
                navigator.clipboard.writeText(publicRecordingUrl);
                alert('Public link copied to clipboard!');
              }}
              className="text-blue-400 hover:text-blue-300 font-medium shrink-0 flex items-center gap-1"
            >
              <Copy className="w-3.5 h-3.5" /> Copy Link
            </button>
          </div>
        </div>

        {/* Deliverable 2: System Prompt Summary */}
        <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 text-xs">
          <span className="text-xs font-bold text-blue-400 uppercase tracking-wider block mb-2">
            Deliverable B: Complete System Prompt Text
          </span>
          <pre className="max-h-60 overflow-y-auto bg-slate-900 p-4 rounded-xl border border-slate-800 text-slate-300 font-mono text-[11px] leading-relaxed whitespace-pre-wrap">
            {promptText}
          </pre>
        </div>

        {/* Deliverable 3: Evaluation Criteria Matrix */}
        <div className="p-4 bg-slate-950 rounded-2xl border border-slate-800 text-xs">
          <span className="text-xs font-bold text-blue-400 uppercase tracking-wider block mb-2">
            Deliverable C: Business Logic & Underwriting Matrix
          </span>
          <div className="space-y-2">
            <div className="flex items-start gap-2 text-slate-300">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <span><strong>All 7 Criteria Sequenced & Guarded:</strong> Residential/Commercial/Industrial, Sole/Joint, Originals, Up to 75L, Bank Income, Market Value, 3-15 Years.</span>
            </div>
            <div className="flex items-start gap-2 text-slate-300">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <span><strong>Immediate Disqualification:</strong> Disqualifies and exits politely if customer has Agricultural land, Cash income, or missing deeds.</span>
            </div>
            <div className="flex items-start gap-2 text-slate-300">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <span><strong>The "Transfer" Logic Switch:</strong> Diverts existing home loans to the specialized Balance Transfer desk.</span>
            </div>
            <div className="flex items-start gap-2 text-slate-300">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <span><strong>Multi-Slot & Busy States:</strong> Naturally fills slots out of order and schedules callbacks when customer is busy.</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
