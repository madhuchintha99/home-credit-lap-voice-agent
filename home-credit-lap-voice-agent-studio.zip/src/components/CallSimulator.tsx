import React, { useState, useEffect, useRef } from 'react';
import { 
  Phone, 
  PhoneCall, 
  PhoneOff, 
  Mic, 
  MicOff, 
  Volume2, 
  VolumeX, 
  Send, 
  UserCheck, 
  Sparkles, 
  Activity, 
  RefreshCw,
  Clock,
  RotateCcw,
  Headphones
} from 'lucide-react';
import { 
  CallStage, 
  EligibilityData, 
  ChatMessage, 
  PromptVariables, 
  CallLog 
} from '../types/agent';
import { 
  processCustomerTurn, 
  INITIAL_ELIGIBILITY_DATA 
} from '../services/voiceAgentEngine';
import { speechService } from '../services/speechService';

interface CallSimulatorProps {
  variables: PromptVariables;
  currentEligibility: EligibilityData;
  onUpdateEligibility: (data: EligibilityData) => void;
  currentStage: CallStage;
  onChangeStage: (stage: CallStage) => void;
  onSaveCallLog: (log: CallLog) => void;
  disqualificationReason?: string;
  setDisqualificationReason: (reason?: string) => void;
}

export const CallSimulator: React.FC<CallSimulatorProps> = ({
  variables,
  currentEligibility,
  onUpdateEligibility,
  currentStage,
  onChangeStage,
  onSaveCallLog,
  disqualificationReason,
  setDisqualificationReason,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputUtterance, setInputUtterance] = useState('');
  const [callDuration, setCallDuration] = useState(0);
  const [isMuted, setIsMuted] = useState(false);
  const [isSpeakerOn, setIsSpeakerOn] = useState(true);
  const [isListeningMic, setIsListeningMic] = useState(false);
  const [isAgentSpeaking, setIsAgentSpeaking] = useState(false);
  const [callActive, setCallActive] = useState(false);
  const [recordingBlob, setRecordingBlob] = useState<Blob | null>(null);

  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const chatScrollRef = useRef<HTMLDivElement | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const mediaStreamDestRef = useRef<MediaStreamAudioDestinationNode | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  // Auto-scroll chat to bottom
  useEffect(() => {
    if (chatScrollRef.current) {
      chatScrollRef.current.scrollTop = chatScrollRef.current.scrollHeight;
    }
  }, [messages, isAgentSpeaking]);

  // Call timer effect
  useEffect(() => {
    if (callActive && currentStage !== 'CALL_ENDED' && currentStage !== 'IDLE') {
      timerRef.current = setInterval(() => {
        setCallDuration((prev) => prev + 1);
      }, 1000);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [callActive, currentStage]);

  const formatTimer = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // Start Call Flow
  const startCall = () => {
    setCallDuration(0);
    setMessages([]);
    onUpdateEligibility(INITIAL_ELIGIBILITY_DATA);
    setDisqualificationReason(undefined);
    setCallActive(true);
    onChangeStage('GREETING_VERIFICATION');

    // Initial Agent Greeting
    const greetingText = `Hello, good day! Am I speaking with ${variables.customer_name}? This is ${variables.agent_name} calling from ${variables.company_name}.`;
    
    const initialMsg: ChatMessage = {
      id: Date.now().toString(),
      sender: 'agent',
      text: greetingText,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
      stageTransition: 'GREETING_VERIFICATION',
    };

    setMessages([initialMsg]);

    if (isSpeakerOn) {
      setIsAgentSpeaking(true);
      speechService.speak(
        greetingText,
        variables.agent_gender,
        () => setIsAgentSpeaking(false),
        () => setIsAgentSpeaking(false)
      );
    }
  };

  // End Call Flow & Save Call Log
  const endCall = (explicitOutcome?: CallLog['outcome'], reason?: string) => {
    speechService.stopSpeaking();
    speechService.stopListening();
    setIsAgentSpeaking(false);
    setIsListeningMic(false);
    setCallActive(false);
    onChangeStage('CALL_ENDED');

    let finalOutcome: CallLog['outcome'] = 'Incomplete';
    if (explicitOutcome) {
      finalOutcome = explicitOutcome;
    } else if (currentStage === 'QUALIFIED_HANDOFF') {
      finalOutcome = 'Qualified';
    } else if (currentStage === 'DISQUALIFIED') {
      finalOutcome = 'Disqualified';
    } else if (currentStage === 'BALANCE_TRANSFER_SWITCH') {
      finalOutcome = 'Balance Transfer';
    } else if (currentStage === 'CALLBACK_SCHEDULED') {
      finalOutcome = 'Callback Scheduled';
    }

    const newLog: CallLog = {
      id: `call_${Date.now()}`,
      callDate: new Date().toLocaleString(),
      durationSeconds: callDuration,
      outcome: finalOutcome,
      outcomeReason: reason || disqualificationReason,
      eligibilityData: currentEligibility,
      messages: messages,
      variables: variables,
    };

    onSaveCallLog(newLog);
  };

  // Handle Customer Utterance
  const handleCustomerSubmit = (utteranceText: string) => {
    const text = utteranceText.trim();
    if (!text || !callActive) return;

    setInputUtterance('');

    const customerMsg: ChatMessage = {
      id: Date.now().toString(),
      sender: 'customer',
      text: text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
    };

    const updatedMessages = [...messages, customerMsg];
    setMessages(updatedMessages);

    // Stop speaking if customer interrupts
    speechService.stopSpeaking();

    // Process through dialog engine
    const turnResult = processCustomerTurn(
      text,
      currentStage,
      currentEligibility,
      variables
    );

    // Update eligibility data
    onUpdateEligibility(turnResult.updatedEligibility);
    onChangeStage(turnResult.nextStage);

    if (turnResult.disqualificationReason) {
      setDisqualificationReason(turnResult.disqualificationReason);
    }

    // Add agent response
    const agentMsg: ChatMessage = {
      id: (Date.now() + 1).toString(),
      sender: 'agent',
      text: turnResult.replyText,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
      stageTransition: turnResult.nextStage,
      disqualificationReason: turnResult.disqualificationReason,
    };

    setMessages([...updatedMessages, agentMsg]);

    // Speak response if speaker enabled
    if (isSpeakerOn) {
      setIsAgentSpeaking(true);
      speechService.speak(
        turnResult.replyText,
        variables.agent_gender,
        () => {
          setIsAgentSpeaking(false);
          if (turnResult.isTerminal) {
            // Wait 1.5 seconds after final sentence before hanging up
            setTimeout(() => {
              if (turnResult.nextStage === 'QUALIFIED_HANDOFF') endCall('Qualified');
              else if (turnResult.nextStage === 'DISQUALIFIED') endCall('Disqualified', turnResult.disqualificationReason);
              else if (turnResult.nextStage === 'BALANCE_TRANSFER_SWITCH') endCall('Balance Transfer');
              else if (turnResult.nextStage === 'CALLBACK_SCHEDULED') endCall('Callback Scheduled');
              else endCall();
            }, 1200);
          }
        },
        () => setIsAgentSpeaking(false)
      );
    } else if (turnResult.isTerminal) {
      setTimeout(() => {
        if (turnResult.nextStage === 'QUALIFIED_HANDOFF') endCall('Qualified');
        else if (turnResult.nextStage === 'DISQUALIFIED') endCall('Disqualified', turnResult.disqualificationReason);
        else if (turnResult.nextStage === 'BALANCE_TRANSFER_SWITCH') endCall('Balance Transfer');
        else if (turnResult.nextStage === 'CALLBACK_SCHEDULED') endCall('Callback Scheduled');
        else endCall();
      }, 1000);
    }
  };

  // Microphone STT toggle
  const toggleMicrophone = () => {
    if (isListeningMic) {
      speechService.stopListening();
      setIsListeningMic(false);
    } else {
      const started = speechService.startListening(
        (transcript) => {
          handleCustomerSubmit(transcript);
        },
        (error) => {
          console.warn('Microphone error:', error);
          setIsListeningMic(false);
        },
        () => {
          setIsListeningMic(false);
        }
      );
      if (started) {
        setIsListeningMic(true);
      }
    }
  };

  // Quick utterance suggestions
  const quickResponses = [
    { label: 'Yes, speaking', text: 'Yes, this is Rajesh Sharma speaking. Tell me.' },
    { label: 'Residential Flat', text: 'It is a residential 3BHK flat in Pune where we live.' },
    { label: 'Commercial Shop', text: 'It is a commercial retail shop in the city market.' },
    { label: 'Agricultural Land (Disqualify)', text: 'I have 5 acres of agricultural farmland in Punjab.' },
    { label: 'Sole Owner', text: 'I am the sole owner of this property.' },
    { label: 'Joint Owner', text: 'It is jointly owned with my spouse.' },
    { label: 'Original Docs Ready', text: 'Yes, I have all original deeds and possession papers ready in locker.' },
    { label: 'Only Photocopy (Disqualify)', text: 'I only have photocopies, original papers are missing.' },
    { label: 'Borrow ₹50 Lakhs', text: 'I am looking to borrow 50 Lakh rupees.' },
    { label: 'Need ₹1.2 Crore (>75L)', text: 'I need around 1 Crore 20 Lakhs for business expansion.' },
    { label: 'Agree to ₹75L Cap', text: 'Alright, 75 Lakhs is fine, let us proceed with that.' },
    { label: 'Salaried in Bank', text: 'I am salaried at Infosys, salary is credited directly to my bank.' },
    { label: 'Cash Income (Disqualify)', text: 'I take all my earnings in cash only, no bank accounts.' },
    { label: 'Market Value ₹1.2 Cr', text: 'The current market value is around 1.25 Crores.' },
    { label: '10 Years Tenure', text: 'I would like to take 10 years to repay the loan.' },
    { label: 'Balance Transfer / EMI', text: 'I already have a home loan and want to transfer it to lower my EMI.' },
    { label: 'Busy / Callback', text: 'I am in an urgent meeting right now, please call me back tomorrow 3 PM.' },
    { label: 'Multi-Slot Combo', text: 'I run a business and need 40 lakhs for 7 years on my commercial shop.' },
  ];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 h-full">
      {/* LEFT: Phone Simulator & Live Waveform (5 cols) */}
      <div className="lg:col-span-5 flex flex-col justify-between bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl relative overflow-hidden">
        {/* Ambient Top Glow */}
        <div className="absolute -top-24 left-1/2 -translate-x-1/2 w-64 h-64 bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />

        {/* Header / Network Bar */}
        <div className="flex items-center justify-between text-xs text-slate-400 pb-4 border-b border-slate-800/80">
          <div className="flex items-center gap-1.5 font-medium">
            <span className="w-2 h-2 rounded-full bg-emerald-400" />
            <span>VoIP HD Secure Line</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="font-mono text-slate-300">Retell / Bolna Voice Engine</span>
            <div className="flex items-center gap-0.5">
              <span className="w-1 h-2 bg-slate-400 rounded-sm" />
              <span className="w-1 h-3 bg-slate-400 rounded-sm" />
              <span className="w-1 h-4 bg-slate-400 rounded-sm" />
            </div>
          </div>
        </div>

        {/* Central Caller Persona Display */}
        <div className="flex flex-col items-center justify-center my-6 text-center">
          <div className="relative mb-4">
            <div
              className={`w-28 h-28 rounded-full flex items-center justify-center border-4 transition-all duration-300 ${
                isAgentSpeaking
                  ? 'border-blue-400 ring-8 ring-blue-500/20 shadow-blue-500/50 scale-105'
                  : callActive
                  ? 'border-emerald-500/60 ring-4 ring-emerald-500/10'
                  : 'border-slate-700 bg-slate-800'
              }`}
            >
              <div className="w-24 h-24 rounded-full bg-gradient-to-tr from-blue-600 to-indigo-600 flex items-center justify-center text-white shadow-inner">
                <Headphones className="w-10 h-10" />
              </div>
            </div>

            {/* Speaking Pulse Badge */}
            {isAgentSpeaking && (
              <span className="absolute -bottom-1 -right-1 bg-blue-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-full shadow-lg border border-blue-400 animate-pulse">
                Speaking...
              </span>
            )}
            {isListeningMic && (
              <span className="absolute -bottom-1 -left-1 bg-rose-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-full shadow-lg border border-rose-400 animate-pulse">
                Listening...
              </span>
            )}
          </div>

          <h2 className="text-xl font-bold text-white tracking-wide">
            {variables.agent_name} ({variables.agent_gender})
          </h2>
          <p className="text-xs font-semibold text-blue-400 mt-0.5 tracking-wider uppercase">
            {variables.company_name} AI Advisor
          </p>

          <div className="mt-2 text-xs text-slate-400 flex items-center gap-1.5">
            <span>Customer:</span>
            <span className="text-slate-200 font-medium">{variables.customer_name}</span>
          </div>

          {/* Call Status & Timer */}
          <div className="mt-4 flex items-center gap-2">
            {callActive ? (
              <div className="flex items-center gap-2 bg-slate-800/90 px-4 py-1.5 rounded-full border border-slate-700">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                <span className="font-mono text-sm font-semibold text-emerald-400">
                  {formatTimer(callDuration)}
                </span>
                <span className="text-xs text-slate-400">| In Call</span>
              </div>
            ) : (
              <div className="bg-slate-800/60 px-4 py-1.5 rounded-full border border-slate-700/60 text-xs text-slate-400">
                Call Ready • Outbound Dialer
              </div>
            )}
          </div>

          {/* Animated Audio Waveform */}
          <div className="w-full max-w-xs h-12 flex items-center justify-center gap-1 mt-6 px-4 bg-slate-950/60 rounded-xl border border-slate-800">
            {[40, 65, 85, 45, 95, 70, 50, 80, 60, 90, 75, 40, 85, 55, 30].map((h, i) => (
              <span
                key={i}
                className={`w-1 rounded-full transition-all duration-150 ${
                  isAgentSpeaking
                    ? 'bg-blue-400'
                    : isListeningMic
                    ? 'bg-rose-400'
                    : callActive
                    ? 'bg-slate-600'
                    : 'bg-slate-800'
                }`}
                style={{
                  height: isAgentSpeaking || isListeningMic ? `${Math.max(6, (h * Math.sin((i + callDuration) * 0.8) + h) * 0.4)}px` : '4px',
                }}
              />
            ))}
          </div>
        </div>

        {/* Phone Control Actions */}
        <div className="pt-4 border-t border-slate-800/80">
          <div className="grid grid-cols-4 gap-3 mb-4">
            {/* Mic Toggle */}
            <button
              onClick={toggleMicrophone}
              disabled={!callActive}
              className={`p-3.5 rounded-2xl flex flex-col items-center justify-center gap-1.5 transition-all text-xs font-medium ${
                !callActive
                  ? 'opacity-40 bg-slate-800 text-slate-500 cursor-not-allowed'
                  : isListeningMic
                  ? 'bg-rose-500 text-white shadow-lg shadow-rose-500/30 ring-2 ring-rose-400'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white'
              }`}
              title={isListeningMic ? 'Stop Mic' : 'Speak into Microphone (Web Speech STT)'}
            >
              {isListeningMic ? <Mic className="w-5 h-5 animate-bounce" /> : <Mic className="w-5 h-5" />}
              <span className="text-[10px]">{isListeningMic ? 'Speaking...' : 'Microphone'}</span>
            </button>

            {/* Speaker Toggle */}
            <button
              onClick={() => {
                if (isSpeakerOn) {
                  speechService.stopSpeaking();
                  setIsSpeakerOn(false);
                } else {
                  setIsSpeakerOn(true);
                }
              }}
              className={`p-3.5 rounded-2xl flex flex-col items-center justify-center gap-1.5 transition-all text-xs font-medium ${
                isSpeakerOn
                  ? 'bg-blue-600/20 text-blue-400 border border-blue-500/30'
                  : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
              }`}
              title="Toggle Audio Voice Synthesis (TTS)"
            >
              {isSpeakerOn ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
              <span className="text-[10px]">{isSpeakerOn ? 'TTS Sound On' : 'Muted'}</span>
            </button>

            {/* Reset Call */}
            <button
              onClick={() => {
                speechService.stopSpeaking();
                speechService.stopListening();
                setCallActive(false);
                setCallDuration(0);
                setMessages([]);
                onUpdateEligibility(INITIAL_ELIGIBILITY_DATA);
                setDisqualificationReason(undefined);
                onChangeStage('IDLE');
              }}
              className="p-3.5 rounded-2xl flex flex-col items-center justify-center gap-1.5 bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white transition-all text-xs font-medium"
              title="Reset Call State"
            >
              <RotateCcw className="w-5 h-5" />
              <span className="text-[10px]">Reset</span>
            </button>

            {/* Stop Speech Voice Interrupt */}
            <button
              onClick={() => {
                speechService.stopSpeaking();
                setIsAgentSpeaking(false);
              }}
              disabled={!isAgentSpeaking}
              className={`p-3.5 rounded-2xl flex flex-col items-center justify-center gap-1.5 transition-all text-xs font-medium ${
                isAgentSpeaking
                  ? 'bg-amber-600/20 text-amber-300 border border-amber-500/40 hover:bg-amber-600/30'
                  : 'opacity-40 bg-slate-800 text-slate-500 cursor-not-allowed'
              }`}
              title="Interrupt Agent Speech"
            >
              <Sparkles className="w-5 h-5" />
              <span className="text-[10px]">Interrupt</span>
            </button>
          </div>

          {/* Primary Action Button: Dial or Hang Up */}
          {!callActive ? (
            <button
              onClick={startCall}
              className="w-full py-4 px-6 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold rounded-2xl shadow-xl shadow-emerald-900/40 flex items-center justify-center gap-3 transition-all transform active:scale-[0.98]"
            >
              <PhoneCall className="w-5 h-5 animate-pulse" />
              <span>Simulate Outbound Call to {variables.customer_name}</span>
            </button>
          ) : (
            <button
              onClick={() => endCall('Incomplete', 'Manual hang up by operator')}
              className="w-full py-4 px-6 bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-500 hover:to-red-500 text-white font-bold rounded-2xl shadow-xl shadow-rose-900/40 flex items-center justify-center gap-3 transition-all transform active:scale-[0.98]"
            >
              <PhoneOff className="w-5 h-5" />
              <span>End Call / Hang Up</span>
            </button>
          )}
        </div>
      </div>

      {/* RIGHT: Live Conversation Stream & Customer Input (7 cols) */}
      <div className="lg:col-span-7 flex flex-col bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl h-[720px]">
        {/* Stream Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Activity className="w-4 h-4 text-blue-400" />
            <h3 className="text-sm font-semibold text-slate-200">
              Live Call Transcript & Intent Stream
            </h3>
          </div>
          <div className="text-xs text-slate-400 flex items-center gap-2">
            <span className="bg-slate-800 px-2 py-0.5 rounded text-[11px] font-mono">
              Language: {variables.language_to_speak}
            </span>
            <span className="bg-slate-800 px-2 py-0.5 rounded text-[11px] font-mono">
              Turns: {messages.length}
            </span>
          </div>
        </div>

        {/* Chat Stream Window */}
        <div
          ref={chatScrollRef}
          className="flex-1 overflow-y-auto py-4 space-y-3.5 pr-2"
        >
          {messages.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-6 text-slate-500">
              <Phone className="w-12 h-12 mb-3 text-slate-700 animate-pulse" />
              <p className="text-sm font-medium text-slate-400">Ready to initiate conversation</p>
              <p className="text-xs max-w-sm mt-1 text-slate-500">
                Click "Simulate Outbound Call" to have {variables.agent_name} call {variables.customer_name} for pre-approved LAP qualification.
              </p>
            </div>
          ) : (
            messages.map((msg) => {
              const isAgent = msg.sender === 'agent';
              return (
                <div
                  key={msg.id}
                  className={`flex flex-col ${isAgent ? 'items-start' : 'items-end'}`}
                >
                  {/* Speaker Label */}
                  <div className="flex items-center gap-1.5 text-[11px] text-slate-400 mb-1 px-1">
                    <span className="font-semibold text-slate-300">
                      {isAgent ? `${variables.agent_name} (Voice Agent)` : `${variables.customer_name} (Customer)`}
                    </span>
                    <span>• {msg.timestamp}</span>
                  </div>

                  {/* Bubble */}
                  <div
                    className={`max-w-[85%] rounded-2xl px-4 py-3 text-xs leading-relaxed shadow-md ${
                      isAgent
                        ? 'bg-slate-800/90 text-slate-100 border border-slate-700/80 rounded-tl-sm'
                        : 'bg-blue-600 text-white rounded-tr-sm shadow-blue-900/30'
                    }`}
                  >
                    <p className="whitespace-pre-line">{msg.text}</p>

                    {/* Metadata tags */}
                    {msg.stageTransition && (
                      <div className="mt-2 pt-2 border-t border-slate-700/50 flex flex-wrap items-center gap-1.5">
                        <span className="text-[10px] bg-slate-900/60 text-blue-300 px-2 py-0.5 rounded font-mono">
                          Stage: {msg.stageTransition}
                        </span>
                        {msg.disqualificationReason && (
                          <span className="text-[10px] bg-rose-950/80 text-rose-300 px-2 py-0.5 rounded font-mono border border-rose-800/40">
                            Disqualification: {msg.disqualificationReason}
                          </span>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              );
            })
          )}

          {/* Typing / Speaking indicator */}
          {isAgentSpeaking && (
            <div className="flex items-center gap-2 text-xs text-blue-400 italic py-1 px-2">
              <span className="flex h-2 w-2 rounded-full bg-blue-400 animate-ping" />
              <span>{variables.agent_name} is speaking...</span>
            </div>
          )}
        </div>

        {/* Quick Customer Utterances Bar */}
        <div className="pt-2 pb-2">
          <div className="flex items-center justify-between text-[11px] text-slate-400 mb-1.5">
            <span className="font-medium">Quick Test Prompts (1-Click Customer Responses):</span>
            <span className="text-[10px] text-slate-500">Includes all 7 criteria & edge cases</span>
          </div>
          <div className="flex flex-wrap gap-1.5 max-h-24 overflow-y-auto pr-1">
            {quickResponses.map((qr, idx) => (
              <button
                key={idx}
                disabled={!callActive}
                onClick={() => handleCustomerSubmit(qr.text)}
                className={`text-[11px] px-2.5 py-1 rounded-lg border transition-all text-left truncate max-w-[220px] ${
                  !callActive
                    ? 'opacity-40 bg-slate-800 text-slate-500 border-slate-700 cursor-not-allowed'
                    : qr.label.includes('Disqualify')
                    ? 'bg-rose-950/30 text-rose-300 border-rose-800/40 hover:bg-rose-900/40'
                    : qr.label.includes('Transfer')
                    ? 'bg-amber-950/30 text-amber-300 border-amber-800/40 hover:bg-amber-900/40'
                    : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700 hover:text-white'
                }`}
                title={qr.text}
              >
                {qr.label}
              </button>
            ))}
          </div>
        </div>

        {/* Customer Input Box */}
        <div className="pt-3 border-t border-slate-800">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleCustomerSubmit(inputUtterance);
            }}
            className="flex items-center gap-2"
          >
            <input
              type="text"
              value={inputUtterance}
              onChange={(e) => setInputUtterance(e.target.value)}
              disabled={!callActive}
              placeholder={
                callActive
                  ? 'Speak into microphone or type customer reply (e.g., "I have a residential flat in Delhi")...'
                  : 'Start call above to begin speaking or typing...'
              }
              className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent disabled:opacity-50"
            />
            <button
              type="submit"
              disabled={!callActive || !inputUtterance.trim()}
              className="bg-blue-600 hover:bg-blue-500 disabled:opacity-40 text-white px-4 py-3 rounded-xl flex items-center justify-center transition-all"
              title="Send reply"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
