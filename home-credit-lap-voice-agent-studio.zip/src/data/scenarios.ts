import { TestScenario } from '../types/agent';

export const TEST_SCENARIOS: TestScenario[] = [
  {
    id: 'golden-qualified',
    title: 'Ideal Full Qualification (7/7 Pass)',
    badge: 'Senior Expert Handoff',
    badgeColor: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30',
    description: 'Golden path customer who meets all 7 criteria (Residential, Sole, Original Docs, 50 Lakhs, Salaried Bank, 1.2 Cr value, 10 Yrs). Successfully transitions to Senior Loan Expert.',
    customerProfile: {
      name: 'Mr. Rajesh Sharma',
      phone: '+91 98201 44521',
      expectedOutcome: 'Qualified Handoff to Senior Expert',
    },
    script: [
      {
        customerTurn: "Yes, this is Rajesh Sharma speaking. Who is this?",
        expectedResponseSummary: "Confirms identity, acknowledges loyalty, and presents pre-approved LAP offer up to ₹75 Lakhs.",
      },
      {
        customerTurn: "Sure, I have a couple of minutes. What are the basic requirements?",
        expectedResponseSummary: "Asks Criterion 1: Property Type (Residential, Commercial, Industrial).",
      },
      {
        customerTurn: "It is a residential 3BHK flat in Pune where my family and I currently live.",
        expectedResponseSummary: "Notes Residential (Eligible). Asks Criterion 2: Ownership Status (Sole or Joint).",
      },
      {
        customerTurn: "I am the sole owner. The registry is exclusively in my name.",
        expectedResponseSummary: "Notes Sole Ownership (Eligible). Asks Criterion 3: Document Availability.",
      },
      {
        customerTurn: "Yes, absolutely. I have all original deeds and possession papers safely in my bank locker.",
        expectedResponseSummary: "Notes Original Documents Available (Eligible). Asks Criterion 4: Loan Amount.",
      },
      {
        customerTurn: "I was looking for around 50 Lakhs to fund my child's higher education abroad.",
        expectedResponseSummary: "Notes ₹50 Lakhs (Eligible, <= 75L). Asks Criterion 5: Occupation & Income Mode.",
      },
      {
        customerTurn: "I work as an IT Project Manager at Infosys. My salary comes directly into my HDFC bank account.",
        expectedResponseSummary: "Notes Salaried & Bank Income (Eligible). Asks Criterion 6: Estimated Market Value.",
      },
      {
        customerTurn: "The current market rate in my society is around 1.25 Crores.",
        expectedResponseSummary: "Notes Market Value ₹1.25 Cr. Asks Criterion 7: Preferred Tenure.",
      },
      {
        customerTurn: "I would like to repay it comfortably over 10 years.",
        expectedResponseSummary: "Notes 10 Years (Eligible, 3-15 yrs). Executes Post-Qualification Handoff to Senior Expert!",
      },
    ],
  },
  {
    id: 'disqualify-agricultural',
    title: 'Disqualification: Agricultural Property',
    badge: 'Immediate Disqualification',
    badgeColor: 'bg-rose-500/10 text-rose-400 border-rose-500/30',
    description: 'Customer offers ancestral agricultural farmland. Under strict underwriting rules, the bot must immediately disqualify and exit without asking remaining questions.',
    customerProfile: {
      name: 'Mr. Vikram Patil',
      phone: '+91 97654 32189',
      expectedOutcome: 'Immediate Disqualification (Agricultural Land)',
    },
    script: [
      {
        customerTurn: "Yes, Vikram speaking. Tell me what this is regarding.",
        expectedResponseSummary: "Greets and presents pre-approved LAP offer up to 75 Lakhs.",
      },
      {
        customerTurn: "Yeah go ahead, I might need some funds.",
        expectedResponseSummary: "Asks Criterion 1: Property Type.",
      },
      {
        customerTurn: "Well, I have 5 acres of fertile agricultural sugarcane land just outside the city.",
        expectedResponseSummary: "Immediately disqualifies! Explains agricultural land is not eligible under policy, thanks customer, and ends call.",
      },
    ],
  },
  {
    id: 'disqualify-cash-income',
    title: 'Disqualification: Cash Income',
    badge: 'Immediate Disqualification',
    badgeColor: 'bg-rose-500/10 text-rose-400 border-rose-500/30',
    description: 'Customer has eligible property and documents, but receives income completely in cash. Bot must immediately terminate under the banking compliance gate.',
    customerProfile: {
      name: 'Mr. Ramesh Gupta',
      phone: '+91 98112 99014',
      expectedOutcome: 'Immediate Disqualification (Cash Income)',
    },
    script: [
      {
        customerTurn: "Speaking. What is this call about?",
        expectedResponseSummary: "Presents LAP loyalty offer up to 75L.",
      },
      {
        customerTurn: "Yes, check my eligibility.",
        expectedResponseSummary: "Asks Criterion 1: Property Type.",
      },
      {
        customerTurn: "It's a commercial shop in the local market.",
        expectedResponseSummary: "Notes Commercial (Eligible). Asks Criterion 2: Ownership.",
      },
      {
        customerTurn: "Sole owner.",
        expectedResponseSummary: "Notes Sole (Eligible). Asks Criterion 3: Document Availability.",
      },
      {
        customerTurn: "Yes, I have original sale deed.",
        expectedResponseSummary: "Notes Original Docs (Eligible). Asks Criterion 4: Loan Amount.",
      },
      {
        customerTurn: "I need 25 Lakhs for inventory.",
        expectedResponseSummary: "Notes 25L (Eligible). Asks Criterion 5: Occupation & Income Mode.",
      },
      {
        customerTurn: "I run the shop, but my customers pay only in cash. I take all earnings in cash, no bank credits.",
        expectedResponseSummary: "Immediately triggers Disqualification! Explains bank-credited income is mandatory, concludes politely, and ends call.",
      },
    ],
  },
  {
    id: 'balance-transfer-switch',
    title: 'The "Transfer" Logic Switch (Existing Loan)',
    badge: 'Specialist Transfer Switch',
    badgeColor: 'bg-amber-500/10 text-amber-400 border-amber-500/30',
    description: 'Customer mentions they already have an existing loan and want lower EMI (Balance Transfer). The agent immediately routes to the dedicated Loan Transfer Specialist desk.',
    customerProfile: {
      name: 'Mrs. Ananya Sen',
      phone: '+91 99031 88765',
      expectedOutcome: 'Specialist Loan Transfer Switch Triggered',
    },
    script: [
      {
        customerTurn: "Yes, this is Ananya. How can I help?",
        expectedResponseSummary: "Presents pre-approved LAP offer up to 75 Lakhs.",
      },
      {
        customerTurn: "Actually, I already have an ongoing home loan on my flat with another bank, and the interest rate is quite high. Can I transfer that to reduce my current EMI?",
        expectedResponseSummary: "Switches to Balance Transfer protocol immediately! Informs that dedicated Loan Transfer Specialist will call shortly, and ends call gracefully.",
      },
    ],
  },
  {
    id: 'over-limit-negotiation',
    title: 'Loan Amount Limit Negotiation (> 75L)',
    badge: 'Boundary Renegotiation',
    badgeColor: 'bg-blue-500/10 text-blue-400 border-blue-500/30',
    description: 'Customer requests ₹1.2 Crores (exceeding the 75 Lakh cap). The agent professionally explains the ceiling and successfully renegotiates to the maximum allowable ₹75 Lakhs.',
    customerProfile: {
      name: 'Dr. Suresh Mehta',
      phone: '+91 98220 54120',
      expectedOutcome: 'Cap Negotiated to 75L -> Full Qualification',
    },
    script: [
      {
        customerTurn: "Yes, speaking. Go ahead.",
        expectedResponseSummary: "Presents offer.",
      },
      {
        customerTurn: "Okay, ask me what you need.",
        expectedResponseSummary: "Asks Property Type.",
      },
      {
        customerTurn: "It is a commercial clinic in Mumbai, owned jointly with my wife. We have original title deeds.",
        expectedResponseSummary: "Captures 3 criteria at once: Commercial, Joint, Original Docs! Asks Loan Amount.",
      },
      {
        customerTurn: "I am expanding my clinic setup, so I need at least 1 Crore 20 Lakhs.",
        expectedResponseSummary: "Detects > 75L! Explains pre-approved loyalty limit is 75 Lakhs, asks if he would like to proceed with max 75L.",
      },
      {
        customerTurn: "Alright, 75 Lakhs will definitely help with the initial equipment. Let's proceed with 75 Lakhs.",
        expectedResponseSummary: "Caps at 75 Lakhs. Asks remaining questions (Occupation, Value, Tenure) and completes qualification.",
      },
    ],
  },
  {
    id: 'out-of-order-multislot',
    title: 'Out-of-Order Multi-Slot Intelligence',
    badge: 'Natural Slot-Filling',
    badgeColor: 'bg-purple-500/10 text-purple-400 border-purple-500/30',
    description: 'Customer blurts out multiple criteria in their first sentence. The agent smartly notes all provided slots and skips already answered questions without repeating.',
    customerProfile: {
      name: 'Mr. Alok Verma',
      phone: '+91 98450 11982',
      expectedOutcome: 'Smart Out-of-Order Filling -> Seamless Handoff',
    },
    script: [
      {
        customerTurn: "Yes, Alok here. What's up?",
        expectedResponseSummary: "Presents offer.",
      },
      {
        customerTurn: "Look, I run a garment export business. I want 40 lakhs for 7 years on my commercial godown, and I have all original deeds ready. What's the rate?",
        expectedResponseSummary: "Smartly extracts 4 SLOTS AT ONCE: Self-Employed, 40L Loan, 7 Years Tenure, Commercial Property, Original Docs! ONLY asks remaining missing points (Ownership & Market Value).",
      },
    ],
  },
  {
    id: 'customer-busy-callback',
    title: 'Busy State / Callback Scheduling',
    badge: 'Polite Callback Scheduled',
    badgeColor: 'bg-sky-500/10 text-sky-400 border-sky-500/30',
    description: 'Customer is in an important board meeting. Agent respects customer time, asks for preferred callback time, confirms schedule, and ends call without being pushy.',
    customerProfile: {
      name: 'Ms. Neha Singhal',
      phone: '+91 98710 44321',
      expectedOutcome: 'Callback Scheduled at Preferred Time',
    },
    script: [
      {
        customerTurn: "Hello, yes this is Neha, but I am right in the middle of a board meeting and cannot talk right now.",
        expectedResponseSummary: "Immediately acknowledges, apologizes for inconvenience, and asks for preferred callback time.",
      },
      {
        customerTurn: "Please call me back tomorrow afternoon around 3:30 PM.",
        expectedResponseSummary: "Confirms callback for tomorrow 3:30 PM, thanks customer warmly, and ends call.",
      },
    ],
  },
];
