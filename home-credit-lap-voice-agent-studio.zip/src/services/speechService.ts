/**
 * Browser Speech Synthesis (TTS) & Web Speech API Recognition (STT) Service
 */

export interface SpeechVoiceOption {
  id: string;
  name: string;
  lang: string;
  gender: 'Female' | 'Male';
}

class SpeechService {
  private synth: SpeechSynthesis | null = null;
  private recognition: any = null;
  private isListening: boolean = false;
  private availableVoices: SpeechSynthesisVoice[] = [];

  constructor() {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      this.synth = window.speechSynthesis;
      this.loadVoices();
      if (this.synth.onvoiceschanged !== undefined) {
        this.synth.onvoiceschanged = () => this.loadVoices();
      }
    }
  }

  private loadVoices() {
    if (this.synth) {
      this.availableVoices = this.synth.getVoices();
    }
  }

  public getVoices(): SpeechSynthesisVoice[] {
    if (this.availableVoices.length === 0 && this.synth) {
      this.availableVoices = this.synth.getVoices();
    }
    return this.availableVoices;
  }

  public speak(
    text: string,
    gender: 'Female' | 'Male' = 'Female',
    onEnd?: () => void,
    onError?: (err: any) => void
  ): Promise<void> {
    return new Promise((resolve) => {
      if (!this.synth) {
        if (onEnd) onEnd();
        resolve();
        return;
      }

      // Stop ongoing speech
      this.synth.cancel();

      const utterance = new SpeechSynthesisUtterance(text);
      utterance.rate = 1.0;
      utterance.pitch = gender === 'Female' ? 1.15 : 0.95;

      const voices = this.getVoices();
      // Try to match Indian English or preferred voice
      const preferred = voices.find(
        (v) =>
          (v.lang.includes('en-IN') || v.name.includes('India') || v.lang.includes('hi-IN')) &&
          (gender === 'Female' ? /female|woman|priya|heera|zira/i.test(v.name) : /male|man|ravi/i.test(v.name))
      ) ||
      voices.find((v) => v.lang.includes('en-IN') || v.name.includes('India')) ||
      voices.find((v) =>
        gender === 'Female'
          ? /female|samantha|karen|victoria|moira/i.test(v.name)
          : /male|daniel|alex|george/i.test(v.name)
      ) ||
      voices[0];

      if (preferred) {
        utterance.voice = preferred;
      }

      utterance.onend = () => {
        if (onEnd) onEnd();
        resolve();
      };

      utterance.onerror = (e) => {
        console.warn('Speech synthesis error/interrupted', e);
        if (onError) onError(e);
        resolve();
      };

      try {
        this.synth.speak(utterance);
      } catch (e) {
        console.error('TTS speak error', e);
        resolve();
      }
    });
  }

  public stopSpeaking() {
    if (this.synth) {
      this.synth.cancel();
    }
  }

  public startListening(
    onResult: (transcript: string) => void,
    onError: (err: string) => void,
    onEnd: () => void
  ): boolean {
    if (typeof window === 'undefined') return false;

    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      onError('Speech Recognition is not supported in this browser. You can type in the input box.');
      return false;
    }

    try {
      this.recognition = new SpeechRecognition();
      this.recognition.continuous = false;
      this.recognition.interimResults = false;
      this.recognition.lang = 'en-IN'; // Indian English

      this.recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        onResult(transcript);
      };

      this.recognition.onerror = (event: any) => {
        console.warn('Speech recognition error:', event.error);
        onError(event.error);
      };

      this.recognition.onend = () => {
        this.isListening = false;
        onEnd();
      };

      this.recognition.start();
      this.isListening = true;
      return true;
    } catch (e: any) {
      onError(e.message || 'Error starting microphone');
      return false;
    }
  }

  public stopListening() {
    if (this.recognition && this.isListening) {
      try {
        this.recognition.stop();
      } catch (e) {
        // ignore
      }
      this.isListening = false;
    }
  }

  public getIsListening(): boolean {
    return this.isListening;
  }
}

export const speechService = new SpeechService();
