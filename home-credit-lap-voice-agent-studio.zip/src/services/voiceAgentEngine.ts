import { EligibilityData, CallStage, PromptVariables, ChatMessage } from '../types/agent';

export const INITIAL_ELIGIBILITY_DATA: EligibilityData = {
  propertyType: null,
  propertyTypeEligible: null,
  ownershipStatus: null,
  ownershipEligible: null,
  hasOriginalDocs: null,
  documentStatus: null,
  documentEligible: null,
  loanAmountRequested: null,
  loanAmountApproved: null,
  loanAmountEligible: null,
  loanAmountNegotiated: false,
  occupation: null,
  incomeMode: null,
  incomeEligible: null,
  marketValue: null,
  tenureYears: null,
  tenureEligible: null,
};

export interface AgentTurnResult {
  replyText: string;
  nextStage: CallStage;
  updatedEligibility: EligibilityData;
  disqualificationReason?: string;
  isTerminal: boolean;
  notes?: string;
}

export function parseAmount(text: string): number | null {
  const lower = text.toLowerCase();
  // check for crore
  const crMatch = lower.match(/(\d+(?:\.\d+)?)\s*(?:cr|crore|crores)/);
  if (crMatch) {
    return parseFloat(crMatch[1]) * 10000000;
  }
  // check for lakh
  const lkMatch = lower.match(/(\d+(?:\.\d+)?)\s*(?:lakh|lakhs|lac|lacs|l)/);
  if (lkMatch) {
    return parseFloat(lkMatch[1]) * 100000;
  }
  // check raw numbers like 5000000 or 7500000
  const numMatch = lower.match(/(?:₹|rs\.?|inr)?\s*(\d{5,8})/);
  if (numMatch) {
    return parseInt(numMatch[1], 10);
  }
  // check plain numbers like "50" in context
  const singleNum = lower.match(/\b(\d{1,3})\b/);
  if (singleNum && (lower.includes('amount') || lower.includes('borrow') || lower.includes('need') || lower.includes('want'))) {
    const val = parseInt(singleNum[1], 10);
    if (val <= 100) return val * 100000; // treat as lakhs
  }
  return null;
}

export function parseTenure(text: string): number | null {
  const lower = text.toLowerCase();
  const yrMatch = lower.match(/(\d+)\s*(?:year|years|saal|yr|yrs)/);
  if (yrMatch) {
    return parseInt(yrMatch[1], 10);
  }
  // check lone numbers if asked tenure
  const loneNum = lower.match(/\b([1-9]|1[0-9]|20)\b/);
  if (loneNum && (lower.includes('tenure') || lower.includes('repay') || lower.includes('time') || lower.includes('period'))) {
    return parseInt(loneNum[1], 10);
  }
  return null;
}

/**
 * Intelligent Slot Extraction from arbitrary customer utterances
 */
export function extractSlotsFromText(text: string, currentData: EligibilityData): {
  data: EligibilityData;
  detectedSlots: string[];
  disqualificationFlag?: { reason: string; field: string };
  isBalanceTransfer: boolean;
  isBusy: boolean;
  callbackTime?: string;
  wantsMax75L?: boolean;
} {
  const lower = text.toLowerCase();
  const updated: EligibilityData = { ...currentData };
  const detectedSlots: string[] = [];
  let disqualificationFlag: { reason: string; field: string } | undefined = undefined;

  // Check Busy / Callback
  const isBusy = /busy|driving|in a meeting|call (me )?(later|back)|not a good time|cannot talk|can't talk|talk later|call tomorrow|board meeting/.test(lower);
  let callbackTime: string | undefined = undefined;
  if (isBusy || /tomorrow|pm|am|afternoon|evening|morning|clock|\d{1,2}\s*(?:pm|am)/.test(lower)) {
    const timeMatch = text.match(/(?:tomorrow|today|afternoon|evening|morning|\d{1,2}(?::\d{2})?\s*(?:am|pm)?)/gi);
    if (timeMatch && timeMatch.length > 0) {
      callbackTime = timeMatch.join(' ');
    }
  }

  // Check Balance Transfer / Existing Loan
  const isBalanceTransfer = /(existing|already have a?|ongoing|current)\s*(home loan|lap|loan)|balance transfer|reduce (my |our )?emi|lower (my |our )?emi|transfer (the |my )?loan/.test(lower);

  // Check agreement to 75L ceiling
  const wantsMax75L = /(yes|sure|okay|alright|fine|proceed with|let's go with|75 lakhs? is fine|75 is fine)/i.test(lower) && 
    (lower.includes('75') || lower.includes('maximum') || lower.includes('limit') || lower.includes('proceed') || lower.includes('fine') || lower.includes('okay'));

  // 1. Property Type Extraction & Eligibility
  if (!updated.propertyType) {
    if (/agri|agriculture|agricultural|farmland|khet|farm land|crop/.test(lower)) {
      updated.propertyType = 'Agricultural';
      updated.propertyTypeEligible = false;
      detectedSlots.push('Property Type (Agricultural)');
      disqualificationFlag = {
        field: 'propertyType',
        reason: 'Agricultural properties are not eligible under Home Credit LAP policy. Only Residential, Commercial, or Industrial properties are eligible.',
      };
    } else if (/resident|residential|house|flat|apartment|villa|home|kothi/.test(lower)) {
      updated.propertyType = 'Residential';
      updated.propertyTypeEligible = true;
      detectedSlots.push('Property Type (Residential)');
    } else if (/commercial|shop|office|godown|showroom|commercial unit|retail space/.test(lower)) {
      updated.propertyType = 'Commercial';
      updated.propertyTypeEligible = true;
      detectedSlots.push('Property Type (Commercial)');
    } else if (/industrial|factory|warehouse|shed|plant|manufacturing unit/.test(lower)) {
      updated.propertyType = 'Industrial';
      updated.propertyTypeEligible = true;
      detectedSlots.push('Property Type (Industrial)');
    }
  }

  // 2. Ownership Status
  if (!updated.ownershipStatus) {
    if (/sole|single|only me|exclusively mine|my own name|myself alone|sole owner/.test(lower)) {
      updated.ownershipStatus = 'Sole';
      updated.ownershipEligible = true;
      detectedSlots.push('Ownership (Sole)');
    } else if (/joint|jointly|with wife|with husband|with partner|with brother|with father|co-owner|joint owner/.test(lower)) {
      updated.ownershipStatus = 'Joint';
      updated.ownershipEligible = true;
      detectedSlots.push('Ownership (Joint)');
    }
  }

  // 3. Document Availability
  if (updated.hasOriginalDocs === null) {
    if (/only photocopy|photocopies|no original|lost documents|missing|don't have original|copies only|papers are with relative/.test(lower)) {
      updated.hasOriginalDocs = false;
      updated.documentStatus = 'Photocopy';
      updated.documentEligible = false;
      detectedSlots.push('Documents (Photocopies only)');
      if (!disqualificationFlag) {
        disqualificationFlag = {
          field: 'documents',
          reason: 'Original title documents are mandatory for verification. Photocopies or missing originals cannot be processed.',
        };
      }
    } else if (/original|yes.*original|have the (papers|documents|deed|registry)|all (deeds|papers|documents) ready|in locker|safe in bank|ready for verification|possession papers/.test(lower) || (/yes/i.test(lower) && lower.includes('document'))) {
      updated.hasOriginalDocs = true;
      updated.documentStatus = 'Original';
      updated.documentEligible = true;
      detectedSlots.push('Documents (Originals Ready)');
    }
  }

  // 4. Loan Amount
  if (updated.loanAmountRequested === null || (updated.loanAmountRequested > 7500000 && !updated.loanAmountApproved)) {
    const parsedAmt = parseAmount(text);
    if (parsedAmt !== null && !lower.includes('worth') && !lower.includes('market value') && !lower.includes('valuation')) {
      updated.loanAmountRequested = parsedAmt;
      if (parsedAmt <= 7500000) {
        updated.loanAmountApproved = parsedAmt;
        updated.loanAmountEligible = true;
        detectedSlots.push(`Loan Amount (₹${(parsedAmt / 100000).toFixed(1)} Lakhs)`);
      } else {
        // Exceeds 75 Lakhs - boundary check
        updated.loanAmountEligible = false;
        detectedSlots.push(`Loan Amount Requested Exceeds Cap: ₹${(parsedAmt / 100000).toFixed(1)}L`);
      }
    }
  }

  // Handle renegotiation to 75 Lakhs
  if (updated.loanAmountRequested && updated.loanAmountRequested > 7500000 && !updated.loanAmountNegotiated) {
    if (wantsMax75L) {
      updated.loanAmountApproved = 7500000;
      updated.loanAmountEligible = true;
      updated.loanAmountNegotiated = true;
      detectedSlots.push('Loan Amount renegotiated to max ceiling ₹75 Lakhs');
    }
  }

  // 5. Occupation & Income Mode
  if (!updated.occupation) {
    if (/salaried|job|working at|employee|it manager|engineer|corporate|monthly salary|tcs|infosys|wipro/.test(lower)) {
      updated.occupation = 'Salaried';
      detectedSlots.push('Occupation (Salaried)');
    } else if (/self-employed|self employed|business|run a|shop owner|proprietorship|businessman|export|trading|clinic|doctor|lawyer|freelancer/.test(lower)) {
      updated.occupation = 'Self-Employed';
      detectedSlots.push('Occupation (Self-Employed)');
    }
  }

  if (!updated.incomeMode) {
    if (/cash|cash in hand|nakad|no bank|customers pay cash|all cash|unaccounted/.test(lower)) {
      updated.incomeMode = 'Cash';
      updated.incomeEligible = false;
      detectedSlots.push('Income Mode (Cash)');
      if (!disqualificationFlag) {
        disqualificationFlag = {
          field: 'income',
          reason: 'Underwriting policy strictly requires income to be routed through registered bank accounts. Cash income is not eligible.',
        };
      }
    } else if (/bank|account|salary account|direct transfer|hdfc|sbi|icici|cheque|neft|rtgs|banking channel/.test(lower)) {
      updated.incomeMode = 'Bank';
      updated.incomeEligible = true;
      detectedSlots.push('Income Mode (Bank Account)');
    }
  }

  // 6. Market Value
  if (updated.marketValue === null) {
    if (/worth|market rate|market value|valuation|valued at|society rate|crore|crores/i.test(lower)) {
      const parsedVal = parseAmount(text);
      if (parsedVal !== null) {
        updated.marketValue = parsedVal;
        detectedSlots.push(`Market Value (₹${(parsedVal / 100000).toFixed(1)} Lakhs)`);
      }
    }
  }

  // 7. Tenure
  if (updated.tenureYears === null) {
    const yr = parseTenure(text);
    if (yr !== null) {
      updated.tenureYears = yr;
      if (yr >= 3 && yr <= 15) {
        updated.tenureEligible = true;
        detectedSlots.push(`Tenure (${yr} Years)`);
      } else {
        updated.tenureEligible = false;
        detectedSlots.push(`Tenure Out of Bounds: ${yr} Years`);
        if (!disqualificationFlag && yr > 15) {
          disqualificationFlag = {
            field: 'tenure',
            reason: `Maximum allowable tenure is 15 years. ${yr} years exceeds the policy limit.`,
          };
        }
      }
    }
  }

  return {
    data: updated,
    detectedSlots,
    disqualificationFlag,
    isBalanceTransfer,
    isBusy,
    callbackTime,
    wantsMax75L,
  };
}

/**
 * Conversational state engine for Home Credit LAP Qualification
 */
export function processCustomerTurn(
  utterance: string,
  currentStage: CallStage,
  currentData: EligibilityData,
  vars: PromptVariables
): AgentTurnResult {
  const {
    data: updated,
    disqualificationFlag,
    isBalanceTransfer,
    isBusy,
    callbackTime,
    wantsMax75L,
  } = extractSlotsFromText(utterance, currentData);

  // 1. Balance Transfer Trigger Switch
  if (isBalanceTransfer) {
    return {
      replyText: `I completely understand, ${vars.customer_name}. Since you already have an ongoing loan and are looking to reduce your current EMI, we have a specialized Balance Transfer desk that offers preferential interest rates and top-up facilities. I am routing your request directly to our Loan Transfer Specialist, who will contact you shortly to review your existing loan details. Thank you for your continued relationship with ${vars.company_name}!`,
      nextStage: 'BALANCE_TRANSFER_SWITCH',
      updatedEligibility: updated,
      isTerminal: true,
      notes: 'Customer transferred to specialized Loan Transfer desk for existing EMI reduction.',
    };
  }

  // 2. Customer Busy / Callback scheduling
  if (isBusy || (currentStage === 'GREETING_VERIFICATION' && /busy|not now|call later|meeting/i.test(utterance))) {
    const timing = callbackTime || 'at a later convenient time';
    return {
      replyText: `I completely understand, ${vars.customer_name}. We certainly do not want to disturb you. I have marked your preference for a callback ${timing}. One of our senior representatives from ${vars.company_name} will reach out to you then. Have a great day ahead!`,
      nextStage: 'CALLBACK_SCHEDULED',
      updatedEligibility: updated,
      isTerminal: true,
      notes: `Callback scheduled: ${timing}`,
    };
  }

  // 3. Immediate Disqualification Checks
  if (disqualificationFlag) {
    let msg = `Thank you for sharing those details, ${vars.customer_name}. `;
    if (disqualificationFlag.field === 'propertyType') {
      msg += `Under our underwriting policy for this pre-approved offer, agricultural properties cannot be pledged. We can only process Residential, Commercial, or Industrial properties. Therefore, we will not be able to proceed with this specific offer today.`;
    } else if (disqualificationFlag.field === 'income') {
      msg += `As per ${vars.company_name}'s credit compliance guidelines, having your income credited through official banking channels is mandatory. Since your income is received in cash, we cannot process this pre-approved facility.`;
    } else if (disqualificationFlag.field === 'documents') {
      msg += `Original property documents and registered deeds are mandatory for our legal verification. Because original documents are not available, we cannot take this application forward at this time.`;
    } else if (disqualificationFlag.field === 'tenure') {
      msg += `Our loan repayment period is strictly between 3 and 15 years. Since your preferred repayment duration falls outside this window, we cannot sanction this specific facility.`;
    } else {
      msg += `Unfortunately, you do not meet the preliminary criteria for this specific pre-approved scheme at this time.`;
    }
    msg += ` We truly value your trust and look forward to serving you with other financial products in the future. Thank you for your time, and have a wonderful day!`;

    return {
      replyText: msg,
      nextStage: 'DISQUALIFIED',
      updatedEligibility: updated,
      disqualificationReason: disqualificationFlag.reason,
      isTerminal: true,
      notes: `Immediate Disqualification triggered on ${disqualificationFlag.field}.`,
    };
  }

  // 4. Over 75 Lakhs Negotiation Gate
  if (updated.loanAmountRequested && updated.loanAmountRequested > 7500000 && !updated.loanAmountNegotiated && !wantsMax75L) {
    const requestedLakhs = (updated.loanAmountRequested / 100000).toFixed(0);
    return {
      replyText: `I note you are looking for ${requestedLakhs} Lakhs, ${vars.customer_name}. However, this exclusive pre-approved loyalty scheme from ${vars.company_name} is capped at a maximum of 75 Lakh rupees. Would you like to proceed with the maximum sanctioned limit of 75 Lakhs?`,
      nextStage: 'COLLECTING_LOAN_AMOUNT',
      updatedEligibility: updated,
      isTerminal: false,
      notes: 'Customer asked for >75L. Offered max ceiling of 75L.',
    };
  }

  // Stage Transitions & Out-of-Order Question Flow
  // Check if we are still at Greeting or Offer stage
  if (currentStage === 'IDLE' || currentStage === 'DIALING' || currentStage === 'GREETING_VERIFICATION') {
    return {
      replyText: `Thank you for confirming, ${vars.customer_name}. As one of our most valued customers, ${vars.company_name} is pleased to offer you an exclusive pre-approved Loan Against Property of up to 75 Lakh rupees at attractive interest rates. May I quickly verify your property and income details to confirm your eligibility? It will take less than two minutes.`,
      nextStage: 'PRESENTING_OFFER',
      updatedEligibility: updated,
      isTerminal: false,
    };
  }

  // Identify next unfulfilled criteria in sequential order:
  // 1. Property Type
  if (!updated.propertyType) {
    return {
      replyText: `Wonderful! To start with, could you please confirm what type of property you own? Is it residential, like a house or flat, commercial, like a shop or office, or an industrial unit?`,
      nextStage: 'COLLECTING_PROPERTY_TYPE',
      updatedEligibility: updated,
      isTerminal: false,
    };
  }

  // 2. Ownership Status
  if (!updated.ownershipStatus) {
    return {
      replyText: `Thank you. And are you the sole owner of this ${updated.propertyType.toLowerCase()} property, or is it jointly owned with family members or partners?`,
      nextStage: 'COLLECTING_OWNERSHIP',
      updatedEligibility: updated,
      isTerminal: false,
    };
  }

  // 3. Document Availability
  if (updated.hasOriginalDocs === null) {
    return {
      replyText: `Understood. Do you have the original property documents and title deed ready with you for verification?`,
      nextStage: 'COLLECTING_DOCUMENTS',
      updatedEligibility: updated,
      isTerminal: false,
    };
  }

  // 4. Loan Amount
  if (!updated.loanAmountApproved) {
    return {
      replyText: `Great. And how much loan amount are you looking to borrow against this property? Our pre-approved facility provides up to 75 Lakh rupees.`,
      nextStage: 'COLLECTING_LOAN_AMOUNT',
      updatedEligibility: updated,
      isTerminal: false,
    };
  }

  // 5. Occupation & Income Mode
  if (!updated.occupation || !updated.incomeMode) {
    if (!updated.occupation && !updated.incomeMode) {
      return {
        replyText: `Noted. Could you tell me if you are salaried in a job or self-employed with your own business? And is your income received through bank transfer, or in cash?`,
        nextStage: 'COLLECTING_INCOME',
        updatedEligibility: updated,
        isTerminal: false,
      };
    } else if (!updated.incomeMode) {
      return {
        replyText: `And is your ${updated.occupation?.toLowerCase()} income credited through your bank account, or is it received in cash?`,
        nextStage: 'COLLECTING_INCOME',
        updatedEligibility: updated,
        isTerminal: false,
      };
    } else {
      return {
        replyText: `And are you currently salaried or self-employed in a business?`,
        nextStage: 'COLLECTING_INCOME',
        updatedEligibility: updated,
        isTerminal: false,
      };
    }
  }

  // 6. Market Value
  if (!updated.marketValue) {
    return {
      replyText: `Got it. What would be the approximate current market value of your ${updated.propertyType?.toLowerCase()} property?`,
      nextStage: 'COLLECTING_MARKET_VALUE',
      updatedEligibility: updated,
      isTerminal: false,
    };
  }

  // 7. Tenure
  if (!updated.tenureYears) {
    return {
      replyText: `Thank you. Lastly, over how many years would you prefer to repay the loan? We offer flexible tenure options between 3 and 15 years.`,
      nextStage: 'COLLECTING_TENURE',
      updatedEligibility: updated,
      isTerminal: false,
    };
  }

  // ALL 7 CRITERIA ARE MET! -> Handoff Gate
  const loanDisplay = updated.loanAmountApproved ? `₹${(updated.loanAmountApproved / 100000).toFixed(0)} Lakhs` : '₹75 Lakhs';
  const valDisplay = updated.marketValue ? `₹${(updated.marketValue / 100000).toFixed(0)} Lakhs` : 'market value';

  return {
    replyText: `Congratulations, ${vars.customer_name}! Based on all your answers—your ${updated.propertyType} property valued at around ${valDisplay}, original documents ready, verified ${updated.occupation} bank income, and requirement of ${loanDisplay} over ${updated.tenureYears} years—you have successfully passed our preliminary eligibility qualification!

Our Senior Loan Expert will call you back shortly today with your customized interest rate starting from 9.25%, accurate EMI breakdown, and to schedule doorstep document pickup. Thank you for your continued trust in ${vars.company_name}, and have a wonderful day!`,
    nextStage: 'QUALIFIED_HANDOFF',
    updatedEligibility: updated,
    isTerminal: true,
    notes: '7/7 Criteria verified. Qualified Lead handed off to Senior Loan Expert.',
  };
}
