import React, { useState } from 'react';
import { 
  Header, 
  ActiveTab 
} from './components/Header';
import { CallSimulator } from './components/CallSimulator';
import { ChecklistHUD } from './components/ChecklistHUD';
import { PromptViewer } from './components/PromptViewer';
import { ScenariosPanel } from './components/ScenariosPanel';
import { CallLogsModal } from './components/CallLogsModal';
import { SubmissionPackage } from './components/SubmissionPackage';
import { 
  EligibilityData, 
  CallStage, 
  PromptVariables, 
  CallLog, 
  TestScenario 
} from './types/agent';
import { DEFAULT_PROMPT_VARIABLES } from './data/promptTemplate';
import { INITIAL_ELIGIBILITY_DATA } from './services/voiceAgentEngine';
import { TEST_SCENARIOS } from './data/scenarios';

// Initial pre-seeded logs demonstrating assignment compliance
const INITIAL_LOGS: CallLog[] = [
  {
    id: 'call_golden_01',
    callDate: new Date(Date.now() - 3600000 * 2).toLocaleString(),
    durationSeconds: 84,
    outcome: 'Qualified',
    outcomeReason: 'All 7 criteria verified and approved. Handoff to Senior Loan Expert.',
    eligibilityData: {
      propertyType: 'Residential',
      propertyTypeEligible: true,
      ownershipStatus: 'Sole',
      ownershipEligible: true,
      hasOriginalDocs: true,
      documentStatus: 'Original',
      documentEligible: true,
      loanAmountRequested: 5000000,
      loanAmountApproved: 5000000,
      loanAmountEligible: true,
      loanAmountNegotiated: false,
      occupation: 'Salaried',
      incomeMode: 'Bank',
      incomeEligible: true,
      marketValue: 12500000,
      tenureYears: 10,
      tenureEligible: true,
    },
    variables: {
      ...DEFAULT_PROMPT_VARIABLES,
      customer_name: 'Mr. Rajesh Sharma',
    },
    messages: [
      {
        id: '1',
        sender: 'agent',
        text: 'Hello, good day! Am I speaking with Mr. Rajesh Sharma? This is Priya calling from Home Credit India.',
        timestamp: '10:14:02 AM',
        stageTransition: 'GREETING_VERIFICATION',
      },
      {
        id: '2',
        sender: 'customer',
        text: 'Yes, this is Rajesh Sharma speaking. Who is this?',
        timestamp: '10:14:08 AM',
      },
      {
        id: '3',
        sender: 'agent',
        text: 'Thank you for confirming, Mr. Rajesh Sharma. As one of our most valued customers, Home Credit India is pleased to offer you an exclusive pre-approved Loan Against Property of up to 75 Lakh rupees at attractive interest rates. May I quickly verify your property and income details to confirm your eligibility?',
        timestamp: '10:14:18 AM',
        stageTransition: 'PRESENTING_OFFER',
      },
      {
        id: '4',
        sender: 'customer',
        text: 'Sure, I have a couple of minutes. What are the basic requirements?',
        timestamp: '10:14:24 AM',
      },
      {
        id: '5',
        sender: 'agent',
        text: 'Wonderful! To start with, could you please confirm what type of property you own? Is it residential, like a house or flat, commercial, like a shop or office, or an industrial unit?',
        timestamp: '10:14:32 AM',
        stageTransition: 'COLLECTING_PROPERTY_TYPE',
      },
      {
        id: '6',
        sender: 'customer',
        text: 'It is a residential 3BHK flat in Pune where my family and I currently live.',
        timestamp: '10:14:40 AM',
      },
      {
        id: '7',
        sender: 'agent',
        text: 'Thank you. And are you the sole owner of this residential property, or is it jointly owned with family members or partners?',
        timestamp: '10:14:47 AM',
        stageTransition: 'COLLECTING_OWNERSHIP',
      },
      {
        id: '8',
        sender: 'customer',
        text: 'I am the sole owner. The registry is exclusively in my name.',
        timestamp: '10:14:52 AM',
      },
      {
        id: '9',
        sender: 'agent',
        text: 'Understood. Do you have the original property documents and title deed ready with you for verification?',
        timestamp: '10:14:58 AM',
        stageTransition: 'COLLECTING_DOCUMENTS',
      },
      {
        id: '10',
        sender: 'customer',
        text: 'Yes, absolutely. I have all original deeds and possession papers safely in my bank locker.',
        timestamp: '10:15:05 AM',
      },
      {
        id: '11',
        sender: 'agent',
        text: 'Great. And how much loan amount are you looking to borrow against this property? Our pre-approved facility provides up to 75 Lakh rupees.',
        timestamp: '10:15:12 AM',
        stageTransition: 'COLLECTING_LOAN_AMOUNT',
      },
      {
        id: '12',
        sender: 'customer',
        text: 'I was looking for around 50 Lakhs to fund my child\'s higher education abroad.',
        timestamp: '10:15:19 AM',
      },
      {
        id: '13',
        sender: 'agent',
        text: 'Noted. Could you tell me if you are salaried in a job or self-employed with your own business? And is your income received through bank transfer, or in cash?',
        timestamp: '10:15:26 AM',
        stageTransition: 'COLLECTING_INCOME',
      },
      {
        id: '14',
        sender: 'customer',
        text: 'I work as an IT Project Manager at Infosys. My salary comes directly into my HDFC bank account.',
        timestamp: '10:15:33 AM',
      },
      {
        id: '15',
        sender: 'agent',
        text: 'Got it. What would be the approximate current market value of your residential property?',
        timestamp: '10:15:40 AM',
        stageTransition: 'COLLECTING_MARKET_VALUE',
      },
      {
        id: '16',
        sender: 'customer',
        text: 'The current market rate in my society is around 1.25 Crores.',
        timestamp: '10:15:46 AM',
      },
      {
        id: '17',
        sender: 'agent',
        text: 'Thank you. Lastly, over how many years would you prefer to repay the loan? We offer flexible tenure options between 3 and 15 years.',
        timestamp: '10:15:53 AM',
        stageTransition: 'COLLECTING_TENURE',
      },
      {
        id: '18',
        sender: 'customer',
        text: 'I would like to repay it comfortably over 10 years.',
        timestamp: '10:15:58 AM',
      },
      {
        id: '19',
        sender: 'agent',
        text: 'Congratulations, Mr. Rajesh Sharma! Based on all your answers—your Residential property valued at around ₹125 Lakhs, original documents ready, verified Salaried bank income, and requirement of ₹50 Lakhs over 10 years—you have successfully passed our preliminary eligibility qualification!\n\nOur Senior Loan Expert will call you back shortly today with your customized interest rate starting from 9.25%, accurate EMI breakdown, and to schedule doorstep document pickup. Thank you for your continued trust in Home Credit India, and have a wonderful day!',
        timestamp: '10:16:15 AM',
        stageTransition: 'QUALIFIED_HANDOFF',
      },
    ],
  },
  {
    id: 'call_disqualify_agri_02',
    callDate: new Date(Date.now() - 3600000 * 5).toLocaleString(),
    durationSeconds: 28,
    outcome: 'Disqualified',
    outcomeReason: 'Underwriting Gate: Agricultural land is ineligible.',
    eligibilityData: {
      ...INITIAL_ELIGIBILITY_DATA,
      propertyType: 'Agricultural',
      propertyTypeEligible: false,
    },
    variables: {
      ...DEFAULT_PROMPT_VARIABLES,
      customer_name: 'Mr. Vikram Patil',
    },
    messages: [
      {
        id: '1',
        sender: 'agent',
        text: 'Hello, good day! Am I speaking with Mr. Vikram Patil? This is Priya calling from Home Credit India.',
        timestamp: '11:20:00 AM',
        stageTransition: 'GREETING_VERIFICATION',
      },
      {
        id: '2',
        sender: 'customer',
        text: 'Yes, Vikram speaking. Tell me what this is regarding.',
        timestamp: '11:20:05 AM',
      },
      {
        id: '3',
        sender: 'agent',
        text: 'As one of our most valued customers, Home Credit India is pleased to offer you an exclusive pre-approved Loan Against Property of up to 75 Lakh rupees at attractive interest rates. Could you confirm what type of property you own?',
        timestamp: '11:20:14 AM',
        stageTransition: 'COLLECTING_PROPERTY_TYPE',
      },
      {
        id: '4',
        sender: 'customer',
        text: 'Well, I have 5 acres of fertile agricultural sugarcane land just outside the city.',
        timestamp: '11:20:20 AM',
      },
      {
        id: '5',
        sender: 'agent',
        text: 'Thank you for sharing that, Mr. Vikram Patil. Under our underwriting policy for this pre-approved offer, agricultural properties cannot be pledged. We can only process Residential, Commercial, or Industrial properties. Therefore, we will not be able to proceed with this specific offer today. We truly appreciate your time and relationship with us. Have a wonderful day ahead!',
        timestamp: '11:20:31 AM',
        stageTransition: 'DISQUALIFIED',
        disqualificationReason: 'Agricultural properties are not eligible under Home Credit LAP policy.',
      },
    ],
  },
];

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('simulator');
  const [variables, setVariables] = useState<PromptVariables>(DEFAULT_PROMPT_VARIABLES);
  const [eligibilityData, setEligibilityData] = useState<EligibilityData>(INITIAL_ELIGIBILITY_DATA);
  const [currentStage, setCurrentStage] = useState<CallStage>('IDLE');
  const [disqualificationReason, setDisqualificationReason] = useState<string | undefined>();
  const [callLogs, setCallLogs] = useState<CallLog[]>(INITIAL_LOGS);

  const handleSaveCallLog = (log: CallLog) => {
    setCallLogs((prev) => [log, ...prev]);
  };

  const handleSelectScenario = (scenario: TestScenario) => {
    setVariables((prev) => ({
      ...prev,
      customer_name: scenario.customerProfile.name,
    }));
    setActiveTab('simulator');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-blue-600 selection:text-white">
      {/* Top Header & Navigation */}
      <Header
        activeTab={activeTab}
        onChangeTab={setActiveTab}
        variables={variables}
        logsCount={callLogs.length}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8">
        {activeTab === 'simulator' && (
          <div className="space-y-6">
            {/* Top Quick Status Pill */}
            <div className="bg-slate-900/60 border border-slate-800/80 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-3 text-xs">
              <div className="flex items-center gap-2">
                <span className="text-slate-400">Target Product:</span>
                <span className="font-semibold text-white">Loan Against Property (LAP)</span>
                <span className="text-slate-600">•</span>
                <span className="text-slate-400">Ceiling:</span>
                <span className="text-emerald-400 font-bold">₹75,00,000 (75 Lakhs)</span>
                <span className="text-slate-600">•</span>
                <span className="text-slate-400">Active Customer:</span>
                <span className="text-blue-300 font-semibold">{variables.customer_name}</span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setActiveTab('scenarios')}
                  className="text-blue-400 hover:text-blue-300 font-semibold flex items-center gap-1"
                >
                  Load Scenario Presets &rarr;
                </button>
              </div>
            </div>

            {/* Main Simulator & HUD Grid */}
            <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
              {/* Phone & Live Transcript */}
              <div className="xl:col-span-8">
                <CallSimulator
                  variables={variables}
                  currentEligibility={eligibilityData}
                  onUpdateEligibility={setEligibilityData}
                  currentStage={currentStage}
                  onChangeStage={setCurrentStage}
                  onSaveCallLog={handleSaveCallLog}
                  disqualificationReason={disqualificationReason}
                  setDisqualificationReason={setDisqualificationReason}
                />
              </div>

              {/* Live 7-Point Checklist HUD */}
              <div className="xl:col-span-4 h-[720px]">
                <ChecklistHUD
                  data={eligibilityData}
                  currentStage={currentStage}
                  disqualificationReason={disqualificationReason}
                />
              </div>
            </div>
          </div>
        )}

        {activeTab === 'prompt' && (
          <div className="h-[780px]">
            <PromptViewer
              variables={variables}
              onUpdateVariables={setVariables}
            />
          </div>
        )}

        {activeTab === 'scenarios' && (
          <div className="h-[780px]">
            <ScenariosPanel
              onSelectScenario={handleSelectScenario}
              onUpdateCustomerName={(name) =>
                setVariables((prev) => ({ ...prev, customer_name: name }))
              }
              variables={variables}
            />
          </div>
        )}

        {activeTab === 'logs' && (
          <div className="h-[780px]">
            <CallLogsModal logs={callLogs} />
          </div>
        )}

        {activeTab === 'submission' && (
          <div className="h-[780px]">
            <SubmissionPackage
              variables={variables}
              logs={callLogs}
            />
          </div>
        )}
      </main>
    </div>
  );
}
