export type PropertyType = 'Residential' | 'Commercial' | 'Industrial' | 'Agricultural' | 'Other' | null;
export type OwnershipStatus = 'Sole' | 'Joint' | null;
export type DocumentStatus = 'Original' | 'Photocopy' | 'Missing' | 'Unsure' | null;
export type OccupationType = 'Salaried' | 'Self-Employed' | 'Unemployed' | 'Retired' | null;
export type IncomeMode = 'Bank' | 'Cash' | 'Cheque' | null;

export interface EligibilityData {
  // 1. Property Type
  propertyType: PropertyType;
  propertyTypeEligible: boolean | null;
  // 2. Ownership Status
  ownershipStatus: OwnershipStatus;
  ownershipEligible: boolean | null;
  // 3. Document Availability
  hasOriginalDocs: boolean | null;
  documentStatus: DocumentStatus;
  documentEligible: boolean | null;
  // 4. Loan Amount (in INR)
  loanAmountRequested: number | null;
  loanAmountApproved: number | null;
  loanAmountEligible: boolean | null;
  loanAmountNegotiated: boolean;
  // 5. Occupation & Income Mode
  occupation: OccupationType;
  incomeMode: IncomeMode;
  incomeEligible: boolean | null;
  // 6. Market Value (in INR)
  marketValue: number | null;
  // 7. Tenure (in years, 3-15)
  tenureYears: number | null;
  tenureEligible: boolean | null;
}

export type CallStage =
  | 'IDLE'
  | 'DIALING'
  | 'GREETING_VERIFICATION'
  | 'PRESENTING_OFFER'
  | 'COLLECTING_PROPERTY_TYPE'
  | 'COLLECTING_OWNERSHIP'
  | 'COLLECTING_DOCUMENTS'
  | 'COLLECTING_LOAN_AMOUNT'
  | 'COLLECTING_INCOME'
  | 'COLLECTING_MARKET_VALUE'
  | 'COLLECTING_TENURE'
  | 'DISQUALIFIED'
  | 'BALANCE_TRANSFER_SWITCH'
  | 'QUALIFIED_HANDOFF'
  | 'CALLBACK_SCHEDULED'
  | 'CALL_ENDED';

export interface PromptVariables {
  company_name: string;
  customer_name: string;
  agent_name: string;
  agent_gender: 'Female' | 'Male';
  current_date: string;
  current_day: string;
  current_time: string;
  additional_context_from_rag: string;
  language_to_speak: 'English' | 'Hindi' | 'Hinglish';
}

export interface ChatMessage {
  id: string;
  sender: 'agent' | 'customer' | 'system';
  text: string;
  timestamp: string;
  audioUrl?: string;
  extractedSlots?: Partial<EligibilityData>;
  stageTransition?: CallStage;
  disqualificationReason?: string;
}

export interface CallLog {
  id: string;
  callDate: string;
  durationSeconds: number;
  outcome: 'Qualified' | 'Disqualified' | 'Balance Transfer' | 'Callback Scheduled' | 'Incomplete';
  outcomeReason?: string;
  eligibilityData: EligibilityData;
  messages: ChatMessage[];
  variables: PromptVariables;
  recordingBlobUrl?: string;
  audioDuration?: number;
}

export interface TestScenario {
  id: string;
  title: string;
  badge: string;
  badgeColor: string;
  description: string;
  customerProfile: {
    name: string;
    phone: string;
    expectedOutcome: string;
  };
  script: {
    customerTurn: string;
    expectedResponseSummary: string;
  }[];
}
